#define  NO_ENOUGH_SPACE  0

/*table of error message
char err_tab[20][80]=
{"No Enough Space", 
"Fail to open file", 
"Read File Error"
"Tree Pool Overflow"
};
*/

int p_error(char *file, int line, char *err_msg);

