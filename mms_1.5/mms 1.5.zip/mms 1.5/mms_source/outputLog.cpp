#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

#include "outputLog.h"
#include "utils.h"

#define BUFFER_SIZE 100
#define FLOAT_PRECISION 4

using namespace std;

COutputLog &log() 
{
	return *COutputLog::instance();
}

COutputLog *COutputLog::instance_ = NULL;

/**
 This provides a single access point to the class from all other classes
 \version 1.0
 \return the single instance of the singleton class
*/
COutputLog *COutputLog::instance()
{
	if(instance_ == NULL)
		instance_ = new COutputLog();
	return instance_;
}

/**
 the destructor
 \version 1.0
*/
COutputLog::~COutputLog()
{
	if(buffer_.size() > 0)
		writeBuffer_();
}

COutputLog& COutputLog::operator<< (const bool& val )
{
	writeLog_((val?"true":"false"));
	return *this;
}

COutputLog& COutputLog::operator<< (const short& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const unsigned short& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const int& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const unsigned int& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const long& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const unsigned long& val )
{
	stringstream s;
	s << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const float& val )
{
	stringstream s;
	s << setprecision(FLOAT_PRECISION) << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const double& val )
{
	stringstream s;
	s << setprecision(FLOAT_PRECISION) << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const long double& val )
{
	stringstream s;
	s << setprecision(FLOAT_PRECISION) << val;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const char ch )
{
	stringstream s;
	s << ch;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const signed char ch )
{
	stringstream s;
	s << ch;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const unsigned char ch )
{
	stringstream s;
	s << ch;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const char* str )
{
	string s = str;
	writeLog_(s);
	return *this;
}

COutputLog& COutputLog::operator<< (const signed char* str )
{
	stringstream s;
	s << str;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<< (const unsigned char* str )
{
	stringstream s;
	s << str;
	writeLog_(s.str());
	return *this;
}

COutputLog& COutputLog::operator<<(const string &s)
{
	writeLog_(s);
	return *this;
}

void COutputLog::writeLog_(string s)
{
	cout << s;

	if(logFile_ != "") {
		buffer_.push_back(s);
		if(buffer_.size() > BUFFER_SIZE)
			writeBuffer_();
	}	
}

void COutputLog::flushBuffer() 
{
		if(buffer_.size() > 0)
			writeBuffer_();
}	

/**
 this sets the logfile to output to
 \version 1.0
 \param filename the name of the log file
*/
void COutputLog::setLogFile(string filename)
{
	fstream outFile;
	logFile_ = filename;
	outFile.open(logFile_.c_str(), ios::out);
	outFile.close();
}

/**
 default constructor
 \version 1.0
*/
COutputLog::COutputLog()
{
	logFile_ = "";
	buffer_.clear();
}

/**
 periodically write to the log file rather than constantly to reduce overhead
 \version 1.0
*/
void COutputLog::writeBuffer_()
{
	ofstream outFile;

	outFile.open(logFile_.c_str(), ios::app);

	for (unsigned int i = 0; i < buffer_.size(); ++i) {
		outFile << buffer_[i];
	}
	buffer_.clear();

	outFile.close();
}
