#if !defined(PARTITION_H)
#define PARTITION_H

#if !defined(LIST_H)
#include <list>
#define LIST_H
#endif

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#include "phylipAlignment.h"

#define USE_COMMENTS

/**
   \unit
   !Partition
   this unit contains classes and data types for storing and manipulating partitions
*/
 
#if !defined(VECTOR_H)
   #include <vector>
   #define VECTOR_H
#endif

using namespace std;

/**
   represents a part in a partition
*/
typedef struct
{
	vector<int> sites;
	int bound;
}Part;


//forward declaration of move list
class CMoveList;

/**
   contains a partition of sites and methods to manipulate that partition
   \version 1.0
   \author Glenn Conner
*/
class CPartition
{
	public:
 		//file format information    
      	static const char  pBeginning_;
      	static const char  pEnd_;
      	static const char  pSeparator_;
      	static const char  vSeparator_;
        static const char  *comment_;
		            
  		virtual ~CPartition() {};
  		CPartition(CPhylipAlignment *);//trivial partition from an alignment
  		CPartition(CPartition *p);//copy constructor
        CPartition() {};		
		void copy(CPartition *);//copy the partition into this one
				
		//get methods
		int getMSTBound();
		int getPartNum();
		int getSitesNum();
		int getPartSize(int);
        int getPartBound(int);
        int getPartSite(int,int);
        int getSitePartIndex(int site);
        CPhylipAlignment *getPhylipAlignment();
        
        void deletePart_(int);
		void addPart_(Part);
		void replacePart_(int,Part);
        
		//io methods      
		void writePartition(string,CPartition *);
				
		//moves methods
		int move_oneElement(int elem,int i,int j,bool doMove);
		int move_mergeParts(int i,int j,bool doMove);
		void applyMove();
		void trivialiseParts(vector<int> *);
		
		//update the partition using data from another partition
		virtual bool update(CPartition *p) {return false;};		

  protected:
 		int sitesNum_,bound_,partNum_;
      	vector<Part> parts_;
      	CPhylipAlignment *pa_;
		       	
      	//functions for generating partitions
		void generateTrivial_();
		int computeMSTBound_();
       	void init_(CPhylipAlignment *);
       	
      	
		bool taxaEqual_(int,int,int);
		int computeBound_(Part &p);					
};

#endif
