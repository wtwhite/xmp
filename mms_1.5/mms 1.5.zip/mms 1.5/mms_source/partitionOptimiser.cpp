#include <iostream>

#include "partition.h"
#include "partitionFactory.h"
#include "partitionOptimiser.h"
#include "outputLog.h"
#include "utils.h"
#include "argList.h"

/**
   determines whether a merge move will increment the no improvement counter,
   when defined merges will not increment the no imp counter
*/
#define MERGES_COST_0

///**
// makes move selection non random
//*
//#define DEBUG  //uncomment to enable debug mode

using namespace std;

/**
 default constructor
 \version 1.0
*/
CPartitionOptimiser::CPartitionOptimiser()
{
	current_ = NULL;
	treeSites_ = NULL;
	initial_ = NULL;
	initialMoves_ = new CMoveList();
}

/**
 add an initial partition to the optimiser
 \param initial the starting partition to use
 \version 1.0
*/
void CPartitionOptimiser::addInitialPartition(CPartition * initial)
{
	initial_ = initial;
	current_= CPartitionFactory::copyPartition(initial_);
	initialMoves_->generateGoodMoves(initial_);
}

/**
 the destructor
 \version 1.0
*/
CPartitionOptimiser::~CPartitionOptimiser()
{
	if(initial_ != NULL) {
		delete initial_;
		delete current_;
	}
	delete initialMoves_;
	if(treeSites_ != NULL)
		delete treeSites_;
}

/**
 add a list of tree sites (used fro retrivialising and outputting a partition with optimal comparisens
 \version 1.0
 \param list the list of tree site costs
*/
void CPartitionOptimiser::addTreeSitesList(CTreeSiteList * list)
{
	treeSites_ = list;
}

/**
 update the initial partition
 \version 1.0
*/
void CPartitionOptimiser::updateInitialPartition()
{
	if(initial_->update(current_)) {//if the partition has changed in the last update
		initialMoves_->generateGoodMoves(initial_);
		log() << "updated initial partition - new bound: " <<
						 initial_->getMSTBound() << "\n\n";
	}
}

/**
 get the current partition
 \version 1.0
 \return the current partition
*/
CPartition *CPartitionOptimiser::getCurrent()
{
	return current_;
}

/**
 get the initial partition
 \version 1.0
 \return the initial partition
*/
CPartition *CPartitionOptimiser::getInitial()
{
	return initial_;
}

/**
 get the tree site list
 \version 1.0
 \return the tree site list
*/
CTreeSiteList *CPartitionOptimiser::getTreeSiteList()
{
	return treeSites_;
}

/**
 write the current partition to a file
 \version 1.0
 \param filename the file to write to
*/
void CPartitionOptimiser::writeCurrent(string filename)
{
	if (treeSites_ !=NULL)
		current_->writePartition(filename, CPartitionFactory::treePartition(current_, treeSites_));
	else
		current_->writePartition(filename, NULL);
	
}

/**
 write the initial partition to a file
 \version 1.0
 \param filename the file to write to
*/
void CPartitionOptimiser::writeInitial(string filename)
{
	if (treeSites_ !=NULL)
		initial_->writePartition(filename, CPartitionFactory::treePartition(initial_, treeSites_));
	else
		initial_->writePartition(filename, NULL);
}


/**
   performs the minmax squeeze algorithm and returns the value of the bound. now performs a variable number of retrivialisation passes.
   \version 1.5
	\return the final value of the bound
*/
int CPartitionOptimiser::optimise()
{
	int tempBound, noImprovement = 0, retrivPasses = 0;
	vector < int >bound;
	Move move;
	CMoveList goodMoves;
	CPartition *bestPart = NULL;

	current_->copy(initial_);
	goodMoves.copy(initialMoves_);	//set up the list of good moves from the initial good moves list

	while(goodMoves.getSize() > 0)	//while there are moves available continue trying to optimise the bound
	{
#if !defined(DEBUG)
		move = *(goodMoves.getMove((int) (goodMoves.getSize() * (float) rand() / (RAND_MAX + 1.0))));	//pick a random move
#else
		move = *(goodMoves.getMove(0));	//pick the first move in the list (DEBUGGING AND SPEED TESTING)
#endif
		tempBound = current_->getMSTBound();

		(move.move == Move_merge) ?	//perform a move
			current_->move_mergeParts(move.param[0], move.param[1], true)	//do the merge
		:
			current_->move_oneElement(move.param[2], move.param[0], move.param[1], true);	//do the move
			
		string moveType = (move.move == Move_merge) ? "merge" : "oneElement";
		log() << "\tselected " << moveType << " move from " <<
						 goodMoves.getSize() << " possible moves: new bound - " <<
						 current_->getMSTBound() << "\n";

		if(CArgList::instance()->isAssigned("upper") && (current_->getMSTBound() == CArgList::instance()->getInt("upper")))	//if the upperbound has been specified and it has been reached, quit the loop
			break;

		if(tempBound == current_->getMSTBound())	//if the bound hasn't improved since the last iteration...
		{
#if !defined(MERGES_COST_0)
			if(move.move == Move_merge)
				++noImprovement;
#else
			++noImprovement;
#endif
		}
		else
			noImprovement = 0;

		//continue searching as normal as bound is still changing
		if(noImprovement < CArgList::instance()->getInt("nochanges"))
			goodMoves.appendNewMoves(&move, current_);	//add new possible moves to the list
		else if(CArgList::instance()->isAssigned("tree") && (retrivPasses < CArgList::instance()->getInt("retrivpasses")))	//if bound is stuck retrivialise if a tree is specified
		{
			int j;
			vector < int >reset;
			CPartition *optimal;
			++retrivPasses;	//add blocker to prevent operation occuring more than the set maximum

			log() << "\t...retrivialising unoptimised parts (pass " <<
							 retrivPasses << " of " <<
							 CArgList::instance()->getInt("retrivpasses") << ")...\n";

			bound.push_back(current_->getMSTBound());	//record pre retrivialised bound
			sort(bound.begin(), bound.end());	//sort into ascending order (all pre retriv'ed bounds)
			if(bound[bound.size() - 1] == current_->getMSTBound())	//if the current partition is the best so far
			{
				if(bestPart == NULL)
					bestPart = CPartitionFactory::copyPartition(current_);	//create a copy of the best partition (in case later passes are worse)
				else if(current_->getMSTBound() > bestPart->getMSTBound())	//the partition must be BETTER (not equal to the previous best)
					bestPart->copy(current_);	//create a copy of the best partition (in case later passes are worse)
			}
			optimal = CPartitionFactory::treePartition(current_, treeSites_);	//create optimal partition for comparisen

			for (j = 0; j < current_->getPartNum(); ++j)	//find all unoptimised parts
				if(current_->getPartBound(j) != optimal->getPartBound(j))
					reset.push_back(j);

			current_->trivialiseParts(&reset);	//retrivialise unoptimised parts
			delete optimal;	//delete optimal partition

			goodMoves.generateGoodMoves(current_);	//regenerate good moves list
			noImprovement = 0;	//reset noImprovement counter
		}
		else
			break;	//if the bound is stuck and no tree is specified break the loop
	}

	bound.push_back(current_->getMSTBound());	//record final bound
	sort(bound.begin(), bound.end());	//sort into ascending order (all pre retriv'ed bounds plus final result)

	if(bestPart != NULL)	//one of the retrivialised partitions was stored for later
	{
		if(bestPart->getMSTBound() > current_->getMSTBound())	//if it is the best partition
			current_->copy(bestPart);	//copy its contents into this one
		delete bestPart;
	}


	return bound[bound.size() - 1];	//return the largest bound found
}
