#include <stdlib.h>

#include <iostream>
#include <fstream>
#include <algorithm>
#include <numeric>

#include "phylipTree.h"
#include "outputLog.h"

using namespace std;

/**
   loads tree data from a treefile in newick format
   \version 1.0
	\param treeFile filename of a tree to load
	\param pAlignment pointer to a phylip alignment
*/
CPhylipTree::CPhylipTree(string treeFile, CPhylipAlignment * pAlignment)
{
	ifstream inputFile;

	inputFile.open(treeFile.c_str(), ios::in);

	if(!inputFile) {
		log() << "Error: unable to open file (" << treeFile << ").";
		log().flushBuffer();
		exit(1);
	}

	namedNodes_ = new vector < CPhylipTreeNode * >;	//only the root node has a named nodes vector (for fast access to the nodes)

	readTree_(inputFile, pAlignment, *namedNodes_);

	if(namedNodes_->size() < pAlignment->getTaxNum()) {
		log() << "Error: taxa in alignment not present in tree\n";
		log().flushBuffer();
		exit(1);
	}
	else if(namedNodes_->size() > pAlignment->getTaxNum()) {
		log() << "Error: more taxa in tree than in alignment\n";
		log().flushBuffer();
		exit(1);
	}

	inputFile.close();
}


/**
   frees memory assigned to a tree
   \version 1.0
*/
CPhylipTree::~CPhylipTree()
{
	delete namedNodes_;
}


/**
   starts rinsmas algorithm
   \version 1.0
	\param pAlignment pointer to a phylip alignment
   \return a vector of site costs
*/
vector < int >*CPhylipTree::doRinsma(CPhylipAlignment * pAlignment)
{
	int i;
	vector < int >*siteCosts = new vector < int >;

	for (i = 0; i < pAlignment->getSeqLen(); ++i) {
		setNamedStates_(pAlignment, i);
		siteCosts->push_back(rinsmaOnSite_());
	}

	return siteCosts;
}


/**
	sets the named nodes states to those in siteNum of the alignment pAlignment
   \version 1.0
	\param pAlignment pointer to a phylip alignment
	\param siteNum site in the alignment to set the nodes states to
*/
void CPhylipTree::setNamedStates_(CPhylipAlignment * pAlignment, int siteNum)
{
	int i;
	vector < char >newStates;

	for (i = 0; i < namedNodes_->size(); ++i) {
		newStates.clear();
		newStates.push_back(pAlignment->get((*namedNodes_)[i]->getNodeTaxaNum_(), siteNum));
		(*namedNodes_)[i]->setState(newStates);
	}

}
