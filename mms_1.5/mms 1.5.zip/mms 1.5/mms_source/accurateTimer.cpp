#ifdef _WIN32//accuratetimer uses windows specific code
#include <windows.h>
#else
#include <time.h>
#endif

#include "accurateTimer.h"
#include "utils.h"

using namespace std;

CAccurateTimer::CAccurateTimer()
{
#ifdef _WIN32//accuratetimer uses windows specific code
	QueryPerformanceFrequency((LARGE_INTEGER *) & freq_);
#endif
}

CAccurateTimer::~CAccurateTimer()
{
}

/**
 start timing
 \version 1.0
*/
void CAccurateTimer::startTimer()
{
#ifdef _WIN32//accuratetimer uses windows specific code
	QueryPerformanceCounter((LARGE_INTEGER *) & start_);
#else
	start_=(unsigned)time( NULL );
#endif
}

/**
 stop timing
 \return the interval of time between the calls to starttimer and stoptimer
 \version 1.0
*/
double CAccurateTimer::stopTimer()
{
#ifdef _WIN32
	QueryPerformanceCounter((LARGE_INTEGER *) & end_);
	return (double) (end_ - start_) / (double) freq_;
#else
	end_=(unsigned)time( NULL );
	return (double) end_-start_;
#endif	
}

string CAccurateTimer::formatTime()
{
#ifdef WIN32
	int totalTime = (int) ((double)(end_-start_)/ (double) freq_);
#else
	int totalTime = (int) (end_-start_);
#endif
	
	string result= 	intToStr(totalTime / 3600, '0', 2) + ":" +
					intToStr((totalTime  % 3600) / 60, '0', 2) + ":" +
					intToStr(totalTime  - (((totalTime  % 3600) / 60) * 60) - ((totalTime  / 3600) * 3600), '0', 2);
#ifdef WIN32 //because the win32 timing method has more accuracy, add some extra timing info on win32
	string extraAccuracy = floatToStr((float) ((double) (end_ - start_) / (double) freq_)-totalTime,4);
	extraAccuracy.assign(extraAccuracy.begin()+1,extraAccuracy.end());
	result+=extraAccuracy;
#endif
	return result;
	
}


