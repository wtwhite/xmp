#if !defined(PAIRSPLITPARTITION_H)
#define PAIRSPLITPARTITION_H

#include "partition.h"
#include "phylipAlignment.h"

using namespace std;

class CPairSplitPartition:public CPartition {
	public:
		CPairSplitPartition(CPhylipAlignment *);
		~CPairSplitPartition(){};
		bool update(CPartition *){return false;};
};

#endif

