#if !defined(LIKELYGROUPPARTITION_H)
#define LIKELYGROUPPARTITION_H

#if !defined(VECTOR_H)
#define VECTOR_H
#include <vector>
#endif

#include "partition.h"
#include "phylipAlignment.h"

using namespace std;

#include "phylipAlignment.h"
#include "partition.h"

class CLikelyGroupPartition:public CPartition 
{
	public:

      
		CLikelyGroupPartition(CPhylipAlignment *pa,int learningPasses,float occuranceLimit);
		~CLikelyGroupPartition();
	  	bool update(CPartition *p);
	private:
/**
   a site in a neighbourlist
  */ 		
typedef struct
{
   vector<int> neighbours;
} Site;
						/**
         required for likelyGroup partition creation
         \version 1.0
         \author Glenn Conner
      */
      class CNeighbourList
      {
         public:
            CNeighbourList(int);
            ~CNeighbourList(){/*do nothing*/};
      
            int getOccuranceNum(int,int);
            int getSize();
            int getTotal();
      
            void updateNeighbours(CPartition *);
         private:
            vector<Site> sites_;
            int totalOccurances_;
      };
      
	CNeighbourList *neighbourList_;
	int iterations_;
	int learningPasses_;
	float occuranceLimit_;
};

#endif
