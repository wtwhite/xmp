#include <stdlib.h>
#include <sstream>
#include <iomanip>

#include "utils.h"

using namespace std;

string intToStr(int i)
{
	stringstream s;
	s << i;
	return s.str();
}

string floatToStr(float f, int precision)
{
	stringstream s;
	s << setprecision(precision) << f;
	return s.str();
}

string intToStr(int i, char fillChar, int width)
{
	stringstream s;
	s << setw(width) << setfill(fillChar) << i;
	return s.str();
}

