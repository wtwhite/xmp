#if !defined(TREESITELIST_H)
#define TREESITELIST_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#if !defined(VECTOR_H)
#include <vector>
#define VECTOR_H
#endif

#include "phylipAlignment.h"

using namespace std;

/**
   stores a site cost and the index of the site
*/
typedef struct {
	int index, value, pos;
} siteCost;

bool operator<(const siteCost & a, const siteCost & b);

/**
   stores a list of site costs gathered from a tree and phylip alignment
   \version 1.0
   \author Glenn Conner
*/
class CTreeSiteList {
      public:
	CTreeSiteList(string, CPhylipAlignment *);
	~CTreeSiteList() {	/* do nothing */
	};
	void writeSiteCosts(string fileName, string alignmentFileName);
	int getSite(int);
	int getSiteAtPosition(int);
	int getTotal();
      private:
	//file format information    
	static char siteBeginning_;
	static char siteEnd_;
	static char siteSeparator_;
	static char valueSeparator_;

	int total_;
	vector < siteCost > siteCosts_;
};

#endif
