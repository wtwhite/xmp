#if !defined(PHYLIPTREE_H)
#define PHYLIPTREE_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#if !defined(VECTOR_H)
#include <vector>
#define VECTOR_H
#endif

#include "phylipAlignment.h"

using namespace std;


/**
   Stores a phylip tree loaded from newick format, can perform the rinsma algorithm to find the trees site costs
   \version 1.3
   \author Glenn Conner
*/
class CPhylipTreeNode {
      public:
	CPhylipTreeNode();
	~CPhylipTreeNode();

	vector < char >*getState();
	void setState(vector < char >&newStates);
	int getNodeTaxaNum_();
	void setNodeTaxaNum_(int nodeTaxaNum);
      private:
	int nodeTaxaNum_;
	string nodeName_;
	  vector < char >states_;

	void setAsNamed_(CPhylipAlignment * pAlignment, string name);
	string readName_(istream & is);
	void checkStateCombinations_(vector < vector < char > > &childStates, vector < char >&state, int cIndex,
				     bool mBefore);
      protected:
	bool isNamed_;
	vector < CPhylipTreeNode * >children_;
	int rinsmaOnSite_();
	void readTree_(ifstream & is, CPhylipAlignment * pAlignment, vector < CPhylipTreeNode * >&namedNodes);

};


/**
   Stores a root node for a phylip tree loaded from newick format, can perform the rinsma algorithm to find the trees site costs
   \version 1.0
   \author Glenn Conner
*/
class CPhylipTree:public CPhylipTreeNode {
      public:
	CPhylipTree(string treeFile, CPhylipAlignment * pAlignment);
	~CPhylipTree();
	vector < int >*doRinsma(CPhylipAlignment * pAlignment);
      private:
	  vector < CPhylipTreeNode * >*namedNodes_;	//root only for fast access to named nodes
	void setNamedStates_(CPhylipAlignment * pAlignment, int siteNum);
};

#endif
