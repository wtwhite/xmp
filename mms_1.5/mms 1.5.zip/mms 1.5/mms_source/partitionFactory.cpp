#include "partitionFactory.h"

using namespace std;

/**
 create a partition from another partition
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::copyPartition(CPartition * p)
{
	return new CPartition(p);
}

/**
 create a partition from a file and an alignment
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::loadPartition(CPhylipAlignment * pa, string name)
{
	return new CFilePartition(pa, name);
}

/**
 create a trivial partition
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::trivialPartition(CPhylipAlignment * pa)
{
	return new CPartition(pa);
}

/**
 create a partition using the pairsplit algorithm
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::pairSplitPartition(CPhylipAlignment * pa)
{
	return new CPairSplitPartition(pa);
}

/**
 create a partition using the likelygroup algorithm
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::likelyGroupPartition(CPhylipAlignment * pa, int learningPasses, float occuranceLimit)
{
	return new CLikelyGroupPartition(pa, learningPasses, occuranceLimit);
}

/**
 create a partition from a list of tree sites and an existing partition
 \version 1.0
 \return a partition
*/
CPartition *CPartitionFactory::treePartition(CPartition * p, CTreeSiteList * list)
{
	return new CTreePartition(p, list);
}
