#if !defined(BENEFIT_H)
#define BENEFIT_H

using namespace std;

	/**
	   stores a benefit vector
	   \version 1.0
	   \author Glenn Conner
	*/
class CBenefit {
      public:
	CBenefit(int, int);
	 ~CBenefit();
	void decFirstElem();
	void setElem(int, int, int *, int *);
	int getElem(int);
	void removeBenefit(int, int);
	int getGreatestElem(int);
	int getElemCost(int, int *, int *);
      private:
	int *bData_;
	int firstElem_;
};

#endif
