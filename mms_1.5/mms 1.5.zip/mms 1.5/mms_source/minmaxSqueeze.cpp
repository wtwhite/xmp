/* -----------------------------------------------------------------------------
 * minmax squeeze for windows and linux
 * version 1.5
 * features 
 *   -loads alignments in phylip alignment format (.phy)
 *   -loading optimal trees in phylip tree format(.tre) to optimize search  
         NOW SUPPORTS MULTIFURCATING TREES WITH INTERNAL NODE NAMES\STATES  
 *   -loading and saving partitions to/from files
 *   -saving starting partition to a file
 *   -three partition creation algorithms (trivial, pair splitting, and likelyGroup)
 *   -user determined search duration
 *   -determines difficulty of finding the max lower bound on a given alignment
 * 
 * VERSION HISTORY
 * 
 * change between 1.2 - 1.5
 * - rebuilt much of the fundamental architecture to be more extensible
 * - improved logging output (log is now the same as on screen output)
 * - fixed some minor bugs and potential problems
 *
 * change between 1.1 - 1.2
 * - added further shared functions, can now load trees with internal node states and perform Rinsmas algorithm 
 * on the tree.
 * - fixed major memory leak in CDistanceMatrix
 * - can now choose sites to exclude and automatically excludes unneeded sites from an alignment
 * - changed partition file format to include a list of excluded sites, so a loaded partition will automatically exclude sites
 *   so the alignment will be the same as when the partition was saved
 *
 * change between 1.0 - 1.1
 * -created shared library mmsShared to hold functions common to the standard and paralell implementations   
 * -can now load trees with internal node names
 * ---------------------------------------------------------------------------*/


#include <time.h>

#include <algorithm>		//used for sorting the results list
#include <iostream>

#include "utils.h"
#include "phylipAlignment.h"
#include "argList.h"
#include "partitionFactory.h"
#include "treeSiteList.h"
#include "partitionOptimiser.h"
#include "outputLog.h"

using namespace std;

/**
   reads in the required and optional command line arguments
   \version 1.5
	\param argc the number of command line arguments passed
   \param argv an array of strings containing the arguments
*/
void readArguments(int argc, char **argv);

/**
   outputs the expected difficulty of the problem and the chance of success
   \version 1.5
	\param pAlignment pointer to a phylip alignment
*/
void displayDifficulty(CPhylipAlignment * pAlignment);

/**
   display the results of the minmax squeeze to the screen and optionally to a log file
   \version 1.5
	\param bounds a vector of the bounds found during the passes of the minmax algorithm
*/
void displayFinalResults(vector < int >&bounds);

/**
   displays  the results of the current pass and adds it to the end of the results list. 
   outputs to screen and optionally to a log file
	\version 1.5
	\param bound results found by minmax algorithm in the various passes
	\param boundMax highest bound yet found.
*/
void displayPassResult(int bound, int boundMax);


/** 
   main method for standard minmax squeeze
   \version 1.5
*/
int main(int argc, char **argv)
{
	int i, j, passResult, boundMax = -1,iterations;
	unsigned int endTime,startTime=(unsigned)time( NULL ) ;
	vector < int >bounds;
	CPartitionOptimiser optimiser;
	CPhylipAlignment *pAlignment;
	
	readArguments(argc, argv);	//read in command line arguments

	if(CArgList::instance()->isAssigned("log"))
		COutputLog::instance()->setLogFile(CArgList::instance()->getString("log"));

	pAlignment = new CFullAlignment(CArgList::instance()->getString("alignment"));	//load phylip alignment   
	
	/* Note it is important not to remove any sites from the alignment if a partition is to be loaded
	   as a loaded partition will automatically remove sites in the alignment so that the alignment will be in the same
	   state as it was when the partition was saved */
	if(CArgList::instance()->isAssigned("exclude") && CArgList::instance()->isAssigned("loadpart")) {
		log() << "Error: cannot exclude sites when loading a partition.\n";
		exit(1);
	}
	else if(CArgList::instance()->isAssigned("exclude") && !CArgList::instance()->isAssigned("loadpart")) {
		((CFullAlignment *) pAlignment)->excludeSites(CArgList::instance()->getString("exclude"));	//exclude selected items
		((CFullAlignment *) pAlignment)->removeIrrelevantSites();	//trim uninformative sites from the list    
	}
	else if(!CArgList::instance()->isAssigned("loadpart"))
		((CFullAlignment *) pAlignment)->removeIrrelevantSites();	//trim uninformative sites from the list          


	log() << "\ngenerating starting partition ";
	if(CArgList::instance()->isAssigned("loadpart"))	//load a partition from a file
	{
		log() << "from " << CArgList::instance()->getString("loadpart") << "...\n";
		optimiser.
			addInitialPartition(CPartitionFactory::loadPartition(pAlignment, CArgList::instance()->getString("loadpart")));
	}
	else			//or generate a partition using a given algorithm
	{
		log() << "using " << CArgList::instance()->getString("generatepart") << " algorithm...\n";

		if(CArgList::instance()->getString("generatepart") == "default")
			optimiser.addInitialPartition(CPartitionFactory::trivialPartition(pAlignment));
		else if(CArgList::instance()->getString("generatepart") == "pairsplit")
			optimiser.addInitialPartition(CPartitionFactory::pairSplitPartition(pAlignment));
		else if(CArgList::instance()->getString("generatepart") == "likelygroup")
			optimiser.addInitialPartition(CPartitionFactory::likelyGroupPartition(pAlignment,
											      (int) (CArgList::instance()->getInt("iterations") *
												     	CArgList::instance()->getFloat("learningpasses")),
											      		CArgList::instance()->getFloat("groupcutoff")));
	}

	log() << "partition created: initial bound " <<
					optimiser.getInitial()->getMSTBound() << "\n";

	if(CArgList::instance()->isAssigned("tree"))	//if no tree is specified, the optimal sites are unknown
	{
		log() << "\nloading optimal site data from treefile " << CArgList::instance()->getString("tree") << "...\n";
		optimiser.addTreeSitesList(new CTreeSiteList(CArgList::instance()->getString("tree"), pAlignment));
		log() << "optimal site data loaded: bound " << optimiser.getTreeSiteList()->getTotal() << "\n";

		if(!CArgList::instance()->isAssigned("upper"))	//if no upper bound is specified then make the bound from the tree the upper bound
			CArgList::instance()->addInt("upper", optimiser.getTreeSiteList()->getTotal());

		if(CArgList::instance()->isAssigned("savesitecosts"))	//save site costs vector if requested
			optimiser.getTreeSiteList()->writeSiteCosts(CArgList::instance()->getString("savesitecosts"),
								    CArgList::instance()->getString("alignment"));
	}

	if(CArgList::instance()->isAssigned("savestartpart"))	//save the starting partition if savestartpart is set
		optimiser.writeInitial(CArgList::instance()->getString("savestartpart"));

	displayDifficulty(pAlignment);	//output difficulty estimate for problem       

	if(!CArgList::instance()->isAssigned("seed"))
		srand((unsigned) time(NULL));	//seed the random number generator
	else
		srand((unsigned) CArgList::instance()->getInt("seed") % 1000);	//seed the random number generator using a specified seed number

	log() << "\nstarting MinMax Squeeze\n=======================\n\n";
	log() << "generating list of good moves...\n\n";

	iterations=CArgList::instance()->getInt("iterations");
	for (i = 1; i <= iterations; ++i) {
		log() << "pass " << i << " of " <<iterations << "...\n";

		passResult = optimiser.optimise();	//do the minmax squeeze... sounds like some sort of disco dance move
		bounds.push_back(passResult);	//record the bound of the current attempt
		displayPassResult(bounds[bounds.size() - 1], boundMax);	//display the results and update the boundMax  
		
		if (i!=iterations)
			optimiser.updateInitialPartition();

		if(bounds[bounds.size() - 1] > boundMax)	//update the max is applicable
		{
			boundMax = bounds[bounds.size() - 1];
			if(CArgList::instance()->isAssigned("savepart"))	//output the partition to a file if it is a new maximum
				optimiser.writeCurrent(CArgList::instance()->getString("savepart"));
		}
		if(CArgList::instance()->isAssigned("upper") && (boundMax == CArgList::instance()->getInt("upper")))	//if the upperbound has been specified and it has been reached, quit the loop
			break;
	}
	displayFinalResults(bounds);	//output final results distribution

	endTime = (unsigned) time(NULL);	//display the time taken to complete
	log() << "MinMax Squeeze completed in " <<
				 intToStr((endTime - startTime) / 3600, '0', 2) << ":" <<
				 intToStr(((endTime - startTime) % 3600) / 60, '0', 2) << ":" <<
				 intToStr((endTime - startTime) - ((((endTime - startTime) % 3600) / 60) * 60) -
					  (((endTime - startTime) / 3600) * 3600), '0', 2) << "\n";
	//clean up
	delete COutputLog::instance();
	delete CArgList::instance();
	delete pAlignment;

	return 0;
}


void displayPassResult(int bound, int boundMax)
{
	string max = ((bound > boundMax) ? " new maximum!\n\n": (" (current maximum " + intToStr(boundMax) + ")\n\n"));
	log() << "bound: " << bound << max;
}


void displayDifficulty(CPhylipAlignment * pAlignment)
{
	if(CArgList::instance()->isAssigned("upper"))	//if the upper bound is not known then difficulty cannot be estimated
	{
		float diff = (float) pAlignment->getSeqLen() / CArgList::instance()->getInt("upper");
		string chance;

		log() << "\nestimating difficulty of problem (sites/upper bound): " <<
						 diff << "\n";
		if(diff >= 0 && diff < 0.4)
			chance = "unlikely to find a correct soloution\n";
		else if(diff >= 0.4 && diff < 0.7)
			chance = "some chance of finding a correct soloution\n";
		else
			chance = "good chance of finding a correct soloution\n";

		log() << chance;
	}
}

void displayFinalResults(vector < int >&bounds)
{
	int i, j, freq;

	sort(bounds.begin(), bounds.end());	//sort the results into ascending order

	log() << "distribution of max bounds\n======================================\n\n";

	for (i = 0; i < bounds.size(); ++i) {
		log() << "\tbound: " << bounds[i];
		j = i + 1;
		freq = 1;
		while((j < bounds.size()) && (bounds[i] == bounds[j])) {
			++j;
			++freq;
		}
		i = j - 1;

		log() << " - frequency " << (float) freq / bounds.size() << "\n";
	}

	log() << "\n======================================\n\n";

	if(CArgList::instance()->isAssigned("upper"))
		log() << "upper bound (" + CArgList::instance()->getString("upper") << ") is " <<
						 ((CArgList::instance()->getInt("upper") ==
						   bounds[bounds.size() - 1]) ? "" : "not ") <<
						 "equal to max lower bound (" << bounds[bounds.size() - 1] <<
						 ")\n";

}



void readArguments(int argc, char **argv)
{
	//arguments currently recognised by the program
	CArgList::instance()->registerString("log","log file to record progress",false);
	CArgList::instance()->registerString("alignment","a valid phylip alignment file (REQUIRED ARGUMENT)",false);
	CArgList::instance()->registerInt("iterations","number of search passes to perform",false);
	CArgList::instance()->registerInt("nochanges", "max number of iterations with no improvement before beginning new pass",false);
	CArgList::instance()->registerString("loadpart","filename of a partition to use a a starting partition",false);
	CArgList::instance()->registerString("savepart","filename to save best partition to",false);
	CArgList::instance()->registerString("savestartpart","filename to save the starting partition to",false);
	CArgList::instance()->registerString("generatepart", "algorithm used to generate starting partition.\nvalid algorithms:\n\tdefault\n\tpairsplit\n\tlikelygroup",false);
	CArgList::instance()->registerInt("seed", "number between 0 and 1000 to initialise the random number generator",false);
	CArgList::instance()->registerInt("upper", "upper bound expected for the alignment",false);
	CArgList::instance()->registerString("tree","bifurcating tree in phylip format (must also be a tree of the alignment specified with \"alignment\")",false);
	CArgList::instance()->registerFloat("groupcutoff", "number between 0 and 1. sets the limit for what are considered likely groups by the likelygroup algorithm",false);
	CArgList::instance()->registerFloat("learningpasses", "number between 0 and 1 that specifies the percentage of passes used for learning when using the likelygroup algorithm",false);
	CArgList::instance()->registerInt("retrivpasses", "number of retrivialisations to perform (only works when tree is also specified)",false);
	CArgList::instance()->registerString("savesitecosts", "saves a sorted list of site costs from a tree (only works when a tree is specified)",false);
	CArgList::instance()->registerString("exclude","a list of sites to exclude separated by commas or joined by - characters to indicate a range of sites\n",false);

	CArgList::instance()->readArgs(argc, argv);	
	
	//for everything else if not present provide a default value
	if (!CArgList::instance()->isAssigned("iterations"))
		CArgList::instance()->addInt("iterations",5);

	if (!CArgList::instance()->isAssigned("nochanges"))
		CArgList::instance()->addInt("nochanges",5);

	if (!CArgList::instance()->isAssigned("generatepart"))
		CArgList::instance()->addString("generatepart","default");

	if (!CArgList::instance()->isAssigned("groupcutoff"))
		CArgList::instance()->addFloat("groupcutoff",0.35);

	if (!CArgList::instance()->isAssigned("learningpasses"))
		CArgList::instance()->addFloat("learningpasses",0.5);
		
	if (!CArgList::instance()->isAssigned("retrivpasses"))
		CArgList::instance()->addInt("retrivpasses",1);
}

