#include "moveList.h"

/**
   determines whether merge moves that offer no improvement are included, 
   doing this provides a greater amount of possible one moves and therefore a greater chance 
   of finding the true soloution at the cost of speed.
*/
#define EXPANDED_SEARCH

using namespace std;


/**
   empty the list
   \version 1.0
*/
void CMoveList::emptyList()
{
	m_.clear();
}


/**
   add a move to the end of the list
   \version 1.0
	\param newMove the move to be added to the list
*/
void CMoveList::append(Move newMove)
{
	int temp;

	//if the move is a merge the second indice must be greater than the second      
	if((newMove.move == Move_merge) && (newMove.param[0] > newMove.param[1])) {
		temp = newMove.param[0];
		newMove.param[0] = newMove.param[1];
		newMove.param[1] = temp;
	}

	m_.push_back(newMove);
}


/**
   return the move at index in the list
   \version 1.0
	\param index the index number of the move to be returned
	\return the move at the desired index
*/
Move *CMoveList::getMove(int index)
{
	return &(m_[index]);
}


/**
	return the size of the list that contains moves
   \version 1.0
*/
int CMoveList::getSize()
{
	return m_.size();
}

/**
   copy the contents of list2 into a list
   \version 1.0
	\param list2 - pointer to a list which contains the information to copy
*/
void CMoveList::copy(CMoveList * list2)
{
	int i;

	m_.clear();
	for (i = 0; i < list2->getSize(); ++i)
		m_.push_back(*list2->getMove(i));
}


/**
   generates a list of good merge moves on the initial partition part
   \version 1.1
	\param part pointer to a partition
*/
void CMoveList::generateGoodMoves(CPartition * part)
{
	int i, j, k, imp;
	Move newMove;

	emptyList();

	//generate a list of all possible good merge moves
	for (i = 0; i < part->getPartNum(); ++i)
		for (j = i + 1; j < part->getPartNum(); ++j) {
			imp = part->move_mergeParts(i, j, false);
			if(imp > 0) {
				newMove.move = Move_merge;
				newMove.param[0] = i;
				newMove.param[1] = j;
				newMove.boundImp = imp;
				append(newMove);
			}
		}

	//if there are no good merge moves try good oneElement moves
	if(getSize() == 0)
		for (i = 0; i < part->getPartNum(); ++i)
			for (j = 0; j < part->getPartNum(); ++j)
				if(i != j)
					for (k = 0; k < part->getPartSize(i); ++k) {
						imp = part->move_oneElement(k, i, j, false);
#if defined(EXPANDED_SEARCH)
						if(imp >= 0)
#else
						if(imp > 0)
#endif
						{
							newMove.move = Move_oneElement;
							newMove.param[0] = i;
							newMove.param[1] = j;
							newMove.param[2] = k;
							newMove.boundImp = imp;
							append(newMove);
						}
					}

}


/**
	removes invalid entries from list based on the previous move
	\version 1.0
	\param move pointer to a move with now incorrect elements
*/
void CMoveList::removeInvalidMoves_(Move * move)
{
	int i;
	CMoveList tempList;

	//remove all moves that involve now non existant/changed parts
	for (i = 0; i < getSize(); ++i) {
		if(!
		   ((getMove(i)->param[0] == move->param[0]) || (getMove(i)->param[1] == move->param[0])
		    || (getMove(i)->param[0] == move->param[1]) || (getMove(i)->param[1] == move->param[1])))
			tempList.append(*(getMove(i)));
	}
	copy(&tempList);
}


/**
   readjusts the indices in list after a merge move has made them incorrect
   \version 1.0
	\param move pointer to a merge move
*/
void CMoveList::readjustMoves_(Move * move)
{
	int i;

	for (i = 0; i < getSize(); ++i) {
		if(getMove(i)->param[0] > move->param[1])
			getMove(i)->param[0] = getMove(i)->param[0] - 1;

		if(getMove(i)->param[1] > move->param[1])
			getMove(i)->param[1] = getMove(i)->param[1] - 1;
	}
}


/**
   append all possible moves to a move list
	\version 1.0
	\param move pointer to the last performed move
	\param part current partition on a phylip alignment (below)
*/
void CMoveList::appendNewMoves(Move * move, CPartition * part)
{
	int i, j, k, imp;
	int priority, pIteration;
	Move newMove;
	CMoveList *noImpList = new CMoveList();

	removeInvalidMoves_(move);
	if(move->move == Move_merge)
		readjustMoves_(move);

	//this priority variable makes the assumption that if the previous move was a oneElement then there are probably
	//no (or very few) merge moves, so it would be more efficient to search the oneElements before resorting to 
	//searching for merges  
	if(move->move == Move_oneElement)
		priority = 1;
	else
		priority = 0;

	for (pIteration = 0; pIteration < 2; ++pIteration, priority = (1 - priority)) {
		if(priority == 0) {
			//append new merge moves
			for (i = 0; i < part->getPartNum(); ++i) {

				if((move->param[0] != i)) {
					imp = part->move_mergeParts(i, move->param[0], false);
					if(imp > 0) {
						newMove.move = Move_merge;
						newMove.param[0] = i;
						newMove.param[1] = move->param[0];
						newMove.boundImp = imp;
						append(newMove);
					}
#if defined(EXPANDED_SEARCH)
					else if(imp == 0) {
						newMove.move = Move_merge;
						newMove.param[0] = i;
						newMove.param[1] = move->param[0];
						newMove.boundImp = imp;
						noImpList->append(newMove);
					}
#endif
				}

				//if the previous move was a oneElement then check the second part aswell
				if((move->move == Move_oneElement) && (move->param[1] != i)) {
					imp = part->move_mergeParts(i, move->param[1], false);
					if(imp > 0) {
						newMove.move = Move_merge;
						newMove.param[0] = i;
						newMove.param[1] = move->param[1];
						newMove.boundImp = imp;
						append(newMove);
					}
#if defined(EXPANDED_SEARCH)
					else if(imp == 0) {
						newMove.move = Move_merge;
						newMove.param[0] = i;
						newMove.param[1] = move->param[1];
						newMove.boundImp = imp;
						noImpList->append(newMove);
					}
#endif
				}
			}
			if(getSize() != 0)
				break;
		}

		//if there are no good merge moves try good oneElement moves
		if(priority == 1) {
			int p[4];

			for (i = 0; i < part->getPartNum(); ++i) {
				//moving elements of unchanged elements into changed elements
				p[0] = i;
				p[1] = i;
				p[2] = move->param[0];
				p[3] = move->param[1];

				for (j = 0; j < 1; ++j) {
					for (k = 0; k < part->getPartSize(i); ++k) {
						if(i != move->param[0]) {
							imp = part->move_oneElement(k, p[0], p[2], false);

							if(imp > 0) {
								newMove.move = Move_oneElement;
								newMove.param[0] = p[0];
								newMove.param[1] = p[2];
								newMove.param[2] = k;
								newMove.boundImp = imp;
								append(newMove);
							}
							else if(imp == 0) {
								newMove.move = Move_oneElement;
								newMove.param[0] = p[0];
								newMove.param[1] = p[2];
								newMove.param[2] = k;
								newMove.boundImp = imp;
								noImpList->append(newMove);
							}
						}

						if((move->move == Move_oneElement) && (i != move->param[1])) {
							imp = part->move_oneElement(k, p[1], p[3], false);
							if(imp > 0) {
								newMove.move = Move_oneElement;
								newMove.param[0] = p[1];
								newMove.param[1] = p[3];
								newMove.param[2] = k;
								newMove.boundImp = imp;
								append(newMove);
							}
							else if(imp == 0) {
								newMove.move = Move_oneElement;
								newMove.param[0] = p[1];
								newMove.param[1] = p[3];
								newMove.param[2] = k;
								newMove.boundImp = imp;
								noImpList->append(newMove);
							}
						}
					}
					//swap so that changed elements are being moved into unchanged elements
					p[0] = p[2];
					p[2] = i;
					p[1] = p[3];
					p[3] = i;
				}
			}
			if(getSize() != 0)
				break;
		}
	}

	//if there are no good moves and some moves that offer no improvement
	if(getSize() == 0 && noImpList->getSize() != 0)
		copy(noImpList);

	delete noImpList;
}
