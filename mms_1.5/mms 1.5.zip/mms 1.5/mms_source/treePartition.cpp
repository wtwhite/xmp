#include "phylipAlignment.h"
#include "treeSiteList.h"
#include "partition.h"
#include "treePartition.h"

using namespace std;

/**
   creates a partition with the bound information gathered from the optimal sites array. 
   Now creates an actual useable partition, rather than just bound data
	\version 1.1
	\param p pointer to a partition
	\param sites pointer to an optimal sites array
*/
CTreePartition::CTreePartition(CPartition *p,CTreeSiteList *sites)
{
	int i,j;
	Part tempP;
	pa_=p->getPhylipAlignment();
  	partNum_=p->getPartNum();
	sitesNum_=p->getSitesNum();
	bound_=0;
	
	for (i=0;i<partNum_;++i)
	{	
      tempP.bound=0;	
      tempP.sites.clear();
      
		for (j=0;j<p->getPartSize(i);++j)
		{
			tempP.sites.push_back(p->getPartSite(i,j));
		   tempP.bound+=sites->getSiteAtPosition(p->getPartSite(i,j));
      }
      
      parts_.push_back(tempP);
		bound_+=parts_[i].bound;
	}  
}

