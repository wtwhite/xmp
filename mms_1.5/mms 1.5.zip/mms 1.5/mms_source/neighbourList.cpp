#include "likelyGroupPartition.h"

using namespace std;


/**
   creates a neighbourlist with sitesNum sites each with sitesNum neighbours
	\version 1.0
	\param sitesNum number of sites to be stored in the neighbourlist
*/
CLikelyGroupPartition::CNeighbourList::CNeighbourList(int sitesNum)
{
	int i, j;
	Site tempS;

	for (i = 0; i < sitesNum; ++i)
		tempS.neighbours.push_back(0);

	for (i = 0; i < sitesNum; ++i)
		sites_.push_back(tempS);

	totalOccurances_ = 0;

}


/**
   updates the occurance of groupings in the list by reading in groupings from p
	\version 1.0
	\param p pointer to a partition
*/
void CLikelyGroupPartition::CNeighbourList::updateNeighbours(CPartition * p)
{
	int i, j, pIndex, pSite;

	for (i = 0; i < sites_.size(); ++i) {
		pIndex = p->getSitePartIndex(i);

		if(pIndex != -1)
			for (j = 0; j < p->getPartSize(pIndex); ++j) {
				pSite = p->getPartSite(pIndex, j);
				if(pSite != i) {
					++sites_[i].neighbours[pSite];
					++totalOccurances_;
				}
			}
		else
			sites_[i].neighbours[0] = -1;	//site i does not exist

	}
}


/**
   the number of times site i and site j have been in the same part
	\version 1.0
	\param i a site index
	\param j another site index
	\return the number of times site i and site j have been in the same part
*/
int CLikelyGroupPartition::CNeighbourList::getOccuranceNum(int i, int j)
{
	return sites_[i].neighbours[j];
}


/**
   returns the number of sites in the list
   \version 1.0
	\return returns the number of sites in the list 
*/
int CLikelyGroupPartition::CNeighbourList::getSize()
{
	return sites_.size();
}


/**
   returns the number of occurances of all sites (useful for determining whether the list is changing from update to update)
   \version 1.0
   \return returns the number of occurances of all sites
*/
int CLikelyGroupPartition::CNeighbourList::getTotal()
{
	return totalOccurances_;
}
