#if !defined(OUTPUTLOG_H)
#define OUTPUTLOG_H

#if !defined(VECTOR_H)
#define VECTOR_H
#include <vector>
#endif

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

using namespace std;

/**
 This class is a singleton which provides a single access point for all classes in the program to output to
 \author Glenn Conner
 \version 2.0
*/
class COutputLog {
      public:
	~COutputLog();
	static COutputLog *instance();
	
	COutputLog& operator<< (const bool& val );
	COutputLog& operator<< (const short& val );
	COutputLog& operator<< (const unsigned short& val );
	COutputLog& operator<< (const int& val );
	COutputLog& operator<< (const unsigned int& val );
	COutputLog& operator<< (const long& val );
	COutputLog& operator<< (const unsigned long& val );
	COutputLog& operator<< (const float& val );
	COutputLog& operator<< (const double& val );
	COutputLog& operator<< (const long double& val );
	COutputLog& operator<< (const char ch );
	COutputLog& operator<< (const signed char ch );
	COutputLog& operator<< (const unsigned char ch );
	COutputLog& operator<< (const char* str );
	COutputLog& operator<< (const signed char* str );
	COutputLog& operator<< (const unsigned char* str );
	COutputLog& operator<< (const string& s);

	void setLogFile(string filename);
	void flushBuffer(); 
      private:
		static COutputLog *instance_;
		string logFile_;
	  vector < string > buffer_;
	  COutputLog();
	void writeLog_(string s);
	void writeBuffer_();
};

COutputLog &log();



#endif
