#ifndef CARG_H_
#define CARG_H_

using namespace std;

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#if !defined(VECTOR_H)
#define VECTOR_H
#include <vector>
#endif

#include "outputLog.h"
/**
 This class is the base class which arguments inherit from
 \author Glenn Conner
 \version 1.0
*/
class CBaseArg {
      public:
	CBaseArg() {
	} 
	virtual ~ CBaseArg() {
	}
	/**
	 determines whether the variable has been assigned yet
	 \version 1.0
	 \return whether the value has been assigned
	*/
	bool isAssigned() {
		return assigned_;
	}
	/**
	 gets the description assigned to the argument
	 \version 1.0
	 \return a description of the arguments function
	*/
	string getDescription() {
		return description_;
	}
	/**
	set the arguments description
	\version 1.0
	\param description a description of the argument
	*/
	void setDescription(string description) {
		description_ = description;
	}
	/**
	 gets the amount of values assigned to an argument
	 \version 1.0
	 \return the amount of values assigned to an argument
	*/	
	int getValueCount() {
		return argCnt_;
	}
	
      protected:
	string description_;
	bool assigned_;	
	int argCnt_;
};

template < class T >
/**
 This generic class allows multiple argument types to be stored
 \author Glenn Conner
 \version 1.0
*/
class CArg:public CBaseArg {
      public:
	CArg(const T value,bool allowMultipleValues);
	CArg(bool allowMultipleValues);
	~CArg() {
	}	
	const T getValue(int i);
	const T getValue();
	void addValue(const T newValue);		
	
      private:
    bool allowMultipleValues_;
    vector<T> values_;
};

/**
 this constructor initialises the value in the class
 \param value the initial value
 \param allowMultipleValues whether the argument can have more than one value
 \version 1.0
*/
template < class T > CArg < T >::CArg(const T value,bool allowMultipleValues)
{
	argCnt_=1;
	values_.push_back(value);
	assigned_ = true;
	allowMultipleValues_=allowMultipleValues;
}

/**
 the default constructor
 \version 1.0
*/
template < class T > CArg < T >::CArg(bool allowMultipleValues)
{
	argCnt_=0;
	assigned_ = false;
	allowMultipleValues_=allowMultipleValues;
}

/**
 set the value in the class
 \version 1.0
 \param newValue the new value 
*/
template < class T > void CArg < T >::addValue(const T newValue)
{
	if (values_.size()>0 && !allowMultipleValues_) {
		log() << "Error: unable to assign multiple values to argument\n";
		exit(-1);
	} else {
		values_.push_back(newValue);
		assigned_ = true;
		++argCnt_;
	}
}

/**
 get the value stored in the class
 \version 1.0
 \return the value stored in the class
*/
template < class T > const T CArg < T >::getValue(int i)
{
	return values_[i];
}

/**
 get the value stored in the class
 \version 1.0
 \return the value stored in the class
*/
template < class T > const T CArg < T >::getValue()
{
	return values_[0];
}



#endif /*CARG_H_ */
