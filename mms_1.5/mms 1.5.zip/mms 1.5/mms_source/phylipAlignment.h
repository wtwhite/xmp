#if !defined(PHYLIPALIGNMENT_H)
#define PHYLIPALIGNMENT_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#if !defined(VECTOR_H)
#include <vector>
#define VECTOR_H
#endif

/**
   if defined then the CSubAlignment class is implemented using a custom array implementation, othewrwise the STL
   vector class is used. generally the custom implementation offers a slight speed boost
*/
#define USE_ARRAY_IMPLEMENTATION

using namespace std;


/**
   base class which full and sub alignments inherit from
   \author Glenn Conner
   \version 1.0
*/
class CPhylipAlignment {
      public:
	int getTaxNum();
	string getLabel(int index);
	virtual int getIndex(int column) = 0;
	virtual char get(int taxon, int column) = 0;
	virtual int getSeqLen() = 0;
	  virtual ~ CPhylipAlignment() {
	};
      protected:
	typedef vector < char >TaxaSeq;
	void init_(CPhylipAlignment *);
	vector < TaxaSeq > *data_;
	vector < int >*siteIndices_;
	//unsigned char *data_;              // One long contiguous array.  Use charMat[t * seqLen + c] to get char at cth column of taxon t.
	char **labels_;		// Array of strings (e.g. labels[2] is address of 3rd string, labels[2][3] is 4th char of this)
	int numTaxa_;
	int seqLen_;
};

/**
 stores a phylip alignment
 \version 1.2
 \author Glenn Conner
*/
class CFullAlignment:public CPhylipAlignment {
      public:
	CFullAlignment(string fileName);
	~CFullAlignment();
	virtual int getIndex(int column);
	virtual char get(int taxon, int column);
	virtual int getSeqLen();
	void excludeSites(string);
	void removeIrrelevantSites();
	string excludeString();
      private:
	//file format information    
	static char rangeSeparator_;
	static char siteSeparator_;
	static char end_;
	  vector < int >*parseExcluded_(string excludedSites);
	void excludeSite_(int index);
	  vector < int >excluded_;
	void ReadPhylipAlignment_(string & fileName);
};

/**
   this class is used as it means that an actual subalignment doesn't need to be made, rather a virtual one that refers to a full alignment
   \version 1.0
   \author Glenn Conner
*/
class CSubAlignment:public CPhylipAlignment {
      public:
	CSubAlignment(vector < int >*p, CPhylipAlignment * pa);
#if defined(USE_ARRAY_IMPLEMENTATION)
	 ~CSubAlignment() {
		delete[]subIndices_;
	};
#else
	 ~CSubAlignment() {	/*do nothing */
	};
#endif
	void taxaDists(int **);
	virtual char get(int taxon, int column);
	virtual int getIndex(int column);
	virtual int getSeqLen();
      private:
#if defined(USE_ARRAY_IMPLEMENTATION)
	int *subIndices_, subSize_;
#else
	vector < int >subIndices_;
#endif
};

#endif
