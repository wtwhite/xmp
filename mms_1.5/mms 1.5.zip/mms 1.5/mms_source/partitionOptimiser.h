#if !defined(PARTITIONOPTIMISER_H)
#define PARTITIONOPTIMISER_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#include "treeSiteList.h"
#include "partition.h"
#include "moveList.h"

using namespace std;

/**
 This class stores an initial partition and progressively tries to improve that initial partition using a hillclimbing algorithm
 \author Glenn Conner
 \version 1.0
*/
class CPartitionOptimiser {
      public:
	CPartitionOptimiser();
	~CPartitionOptimiser();

	void addTreeSitesList(CTreeSiteList * list);
	void addInitialPartition(CPartition * initial);
	void writeCurrent(string filename);
	void writeInitial(string filename);

	int optimise();
	void updateInitialPartition();

	CPartition *getCurrent();
	CPartition *getInitial();
	CTreeSiteList *getTreeSiteList();

      private:
	  CMoveList * initialMoves_;
	CTreeSiteList *treeSites_;
	CPartition *initial_, *current_;
};

#endif
