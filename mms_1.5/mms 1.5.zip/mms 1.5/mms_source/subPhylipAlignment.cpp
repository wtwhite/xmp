#include "phylipAlignment.h"

using namespace std;

/**
   create a sub-alignment from a full alignment
   \version 1.0
	\param p vector of sites to make up the subalignment
	\param pa a full phylip alignment	
*/
CSubAlignment::CSubAlignment(vector < int >*p, CPhylipAlignment * pa)
{
	int i;

	init_(pa);		//set up data to point to full alignment pa

#if defined(USE_ARRAY_IMPLEMENTATION)
	subIndices_ = new int[p->size()];
	subSize_ = p->size();
#endif

	for (i = 0; i < p->size(); ++i)
#if defined(USE_ARRAY_IMPLEMENTATION)
		subIndices_[i] = (*p)[i];
#else
		subIndices_.push_back((*p)[i]);
#endif
}


/**
   gets the character data from a sub alignment at a give location
   \version 1.0
	\param taxon index of the taxon in a sub alignment
	\param column site in the subalignment for a given taxa	
	\return character data at the given location
*/
char CSubAlignment::get(int taxon, int column)
{
	return (*data_)[taxon][subIndices_[column]];
}

/**
   gets the character site index from a sub alignment at a give location
   \version 1.0
	\param column site in the subalignment for a given taxa	
	\return character data at the given location
*/
int CSubAlignment::getIndex(int column)
{
	return (*siteIndices_)[column];
}


/**
   returns the hamming distances between all taxa in the distance matrix m
   \version 1.0
	\param m a pointer to a distance matrix
*/
void CSubAlignment::taxaDists(int **m)
{
	int i, j, k, result;

	for (i = numTaxa_ - 1; i >= 0; --i)
		for (j = i - 1; j >= 0; --j) {
#if defined(USE_ARRAY_IMPLEMENTATION)
			for (k = subSize_ - 1, result = 0; k >= 0; --k)
				result += ((*data_)[i][subIndices_[k]] != (*data_)[j][subIndices_[k]]);
#else
			for (k = subIndices_.size()_ - 1, result = 0; k >= 0; --k)
				result += ((*data_)[i][subIndices_[k]] != (*data_)[j][subIndices_[k]]);
#endif
			m[i][j] = result;
		}
}


/**
   return the length of a sub alignment
   \version 1.0	
	\return sequence length of a sub alignment
*/
int CSubAlignment::getSeqLen()
{
#if defined(USE_ARRAY_IMPLEMENTATION)
	return subSize_;
#else
	return subIndices_.size();
#endif
}
