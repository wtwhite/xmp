#include "phylipAlignment.h"

using namespace std;


/**
   gets taxon labels
   \version 1.0
	\param index index of the label in the alignment
	\return the label of the taxon at index in an alignment
*/
string CPhylipAlignment::getLabel(int index)
{
	string str = labels_[index];
	return str;
}


/**
   gets the number of taxa in an alignment
	\version 1.0
	\return the number of taxa in the alignment
*/
int CPhylipAlignment::getTaxNum()
{
	return numTaxa_;
}


/**
   initialises the values to point to another alignment
   \version 1.0
   \param pa pointer to a phylip alignment
*/
void CPhylipAlignment::init_(CPhylipAlignment * pa)
{
	data_ = pa->data_;
	labels_ = pa->labels_;
	numTaxa_ = pa->numTaxa_;
	seqLen_ = pa->seqLen_;
	siteIndices_ = pa->siteIndices_;
}
