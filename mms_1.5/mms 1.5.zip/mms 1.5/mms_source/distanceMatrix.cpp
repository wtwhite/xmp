#include "distanceMatrix.h"

using namespace std;


/**
	create the top half of a distance matrix that is n*n and fill with data from a subphylip alignment
   \version 1.0
	\param pa - pointer to a sub phylip alignment
*/
CDistanceMatrix::CDistanceMatrix(CSubAlignment * pa)
{
	int i;

	taxaNum_ = pa->getTaxNum();

	m_ = new int *[taxaNum_];
	for (i = 0; i < taxaNum_; ++i)
		m_[i] = new int[i + 1];

	pa->taxaDists(m_);
}


/**
   free the memory allocated to the matrix
   \version 1.0
*/
CDistanceMatrix::~CDistanceMatrix()
{
	int i;

	for (i = taxaNum_ - 1; i >= 0; --i)
		delete[]m_[i];
	delete[]m_;
}


/**
	returns all the indices of taxa that are unique
   \version 1.0
	\param uTNum pointer to the number of unique taxa
	\return  a pointer to an array containing the indices of the unique taxa 
*/
int *CDistanceMatrix::computeUniqueTaxa_(int *uTNum)
{
	int i, j, k, uniqueNum = 0;
	int *uniqueIndices;

	//find how big the array has to be
	for (i = 0; i < taxaNum_; ++i) {
		for (j = 0, k = 0; j < i; ++j)
			if(m_[i][j] == 0) {
				++k;
				break;
			}
		if(k == 0)
			uniqueNum += 1;
	}

	//create the array
	uniqueIndices = new int[uniqueNum];
	*uTNum = uniqueNum;

	//fill it with the unique taxa indices
	for (i = 0, k = 0, uniqueNum = 0; i < taxaNum_; ++i) {
		for (j = 0, k = 0; j < i; ++j)
			if(m_[i][j] == 0) {
				++k;
				break;
			}
		if(k == 0)
			uniqueIndices[uniqueNum++] = i;
	}

	return uniqueIndices;
}


/**
   determines if a matrix of unique taxa has one, two or more than two one connected components and returns the minimum number of edges required to link all the points in the matrix
   version 1.1 fixed a major memory leak in version 1.0
   \version 1.1
	\return  the bound of the tree of unique taxa
*/
int CDistanceMatrix::computeOneConnected()
{
	int i, umSize, count;
	int *um, *connectedList;

	um = computeUniqueTaxa_(&umSize);

	if(umSize == 1)		//only one unique taxa...must be one connected with bound 0
		return 0;

	connectedList = new int[umSize];	//create the connected test list
	for (i = umSize - 1; i >= 0; --i)	//set the connectedList contents to 0
		connectedList[i] = 0;

	count = 0;
	oneConn_(0, um, umSize, connectedList, &count);	//call the recursive test algorithm

	if(count < umSize)	//test to see if two components exist if there is more than one component
	{
		int min = -1;
		int *compIndex;
		compIndex = new int[umSize];	//determine which components each point belongs to (assuming two components)
		for (i = umSize - 1; i >= 0; --i)
			compIndex[i] = connectedList[i];

		for (i = umSize - 1; i >= 0; --i)	//try and find the second component
			if(connectedList[i] == 0) {
				oneConn_(i, um, umSize, connectedList, &count);
				break;
			}

		if(count == umSize)	//if it determined that only two components exist
		{
			int j;

			for (i = 0; i < umSize; ++i)	//find the shortest distance between the two components
			{
				for (j = i + 1; j < umSize; ++j) {
					if(compIndex[i] != compIndex[j])	//if the two points are in different components
					{
						if(um[i] > um[j])	//due to assymmetry of a half matrix the first indice must be greater than the second
						{
							if(m_[um[i]][um[j]] < min)
								min = m_[um[i]][um[j]];
							else if(min == -1)
								min = m_[um[i]][um[j]];
						}
						else {
							if(m_[um[j]][um[i]] < min)
								min = m_[um[j]][um[i]];
							else if(min == -1)
								min = m_[um[j]][um[i]];
						}

						if(min == 2)	//two separate components can't have a min distance<2 so break the loop early
							break;
					}
				}
			}
			delete[]compIndex;
			delete[]um;
			delete[]connectedList;

			return umSize - 2 + min;	//two components
		}
		delete[]compIndex;
	}


	delete[]um;
	delete[]connectedList;

	if(count == umSize)	//one component 
		return umSize - 1;
	else			//more than two components
		return umSize;
}


/**
   recursivly determines if a matrix of unique taxa is one connected
   \version 1.0
	\param index the node currently being checked
	\param um unique taxa in the distance matrix
	\param umSize the number of unique taxa in the matrix
	\param connectedList a list recording which nodes have bonds to other nodes
	\param count records how many nodes have bonds to other nodes
*/
void CDistanceMatrix::oneConn_(int index, int *um, int umSize, int *connectedList, int *count)
{
	int i;
	for (i = 0; (i < umSize) && ((*count) != umSize); ++i)	//check it against all different taxa to see if it is one connected to any of them
	{
		if(um[i] < um[index])	//due to assymmetry of a half matrix the first indice must be greater than the second
		{
			if((m_[um[index]][um[i]] == 1) && (connectedList[i] != 1))	//if there is a one connected element
			{
				if(connectedList[index] != 1)	//index and i are one connected
				{
					connectedList[index] = 1;
					++(*count);
				}
				connectedList[i] = 1;
				++(*count);
				if((*count) != umSize)
					oneConn_(i, um, umSize, connectedList, count);	//check if i is part of a one connected tree
			}
		}
		else if(um[i] > um[index]) {
			if((m_[um[i]][um[index]] == 1) && (connectedList[i] != 1))	//if there is a one connected element
			{
				if(connectedList[index] != 1)	//index and i are one connected
				{
					connectedList[index] = 1;
					++(*count);
				}
				connectedList[i] = 1;
				++(*count);
				if((*count) != umSize)
					oneConn_(i, um, umSize, connectedList, count);	//check if i is part of a one connected tree
			}
		}
	}
}
