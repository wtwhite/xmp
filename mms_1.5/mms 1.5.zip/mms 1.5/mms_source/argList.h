#if !defined(ARGLIST_H)
#define ARGLIST_H

#if !defined(MAP_H)
#define MAP_H
#include <map>
#endif

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

using namespace std;

#include "arg.h"

/**
 This class is responsible for reading and storing command line arguments input by the user
 \version 1.0
 \author glenn conner
*/
class CArgList {
      public:
	~CArgList() {
	} static CArgList *instance();

	void readArgs(int argc, char **argv);

	void registerInt(string name, string description, bool allowMultipleValues);
	void registerChar(string name, string description, bool allowMultipleValues);
	void registerString(string name, string description, bool allowMultipleValues);
	void registerFloat(string name, string description, bool allowMultipleValues);

	void unregisterArg(string name);
	bool isRegistered(string name);
	bool isAssigned(string name);

	int getInt(string name);
	char getChar(string name);
	string getString(string name);
	float getFloat(string name);
	
	int getInt(string name,int i);
	char getChar(string name,int i);
	string getString(string name,int i);
	float getFloat(string name,int i);

	int getCount(string name);
	
	void addInt(string name, int);
	void addChar(string name, char);
	void addString(string name, string);
	void addFloat(string name, float);
	
	void displayArgs();
      private:
	map < string, CBaseArg * >registeredArgs_;
	static CArgList *instance_;

	CArgList() {
	}
	string getType_(string name);
	string readArgName_(const char *str, char separator);
	string readArgValue_(const char *str, char separator);
	void wordWrap_(string & str, int initialPos, int lineLength);

};


#endif
