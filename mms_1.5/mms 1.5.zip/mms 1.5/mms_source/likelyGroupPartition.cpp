#include "phylipAlignment.h"
#include "partition.h"
#include "likelyGroupPartition.h"

using namespace std;

/**
   creates a partition by making parts composed of sites which appear in the same part often (found from n), all remaining parts 
   are added to the end of the partition as trivial parts.
	\version 1.0
	\param pa pointer to a phylip alignment
	\param learningPasses how many passes to conduct before adjusting the partition based on past trends
	\param occuranceLimit value which defines the lower limit for an occurance to be considered likely
*/
CLikelyGroupPartition::CLikelyGroupPartition(CPhylipAlignment *pa,int learningPasses,float occuranceLimit)
{
	
	learningPasses_=learningPasses;
	occuranceLimit_=occuranceLimit;
   	
	init_(pa);	
	generateTrivial_();
	neighbourList_ = new CNeighbourList(pa->getSeqLen());
	iterations_=0;
}


CLikelyGroupPartition::~CLikelyGroupPartition() 
{
	delete neighbourList_;
}

bool CLikelyGroupPartition::update(CPartition *p)
{
   int i,j,k;
   bool *inPartition,best;
   Part tempP;
   
   neighbourList_->updateNeighbours(p);
   
   if ((iterations_++)>learningPasses_) {
		parts_.clear();//clear the current partition
		
		//initialise and zero the inpartition array 
		inPartition = new bool[neighbourList_->getSize()];
		for (i=0;i<neighbourList_->getSize();++i)
		  inPartition[i]=false;
		
		for (i=0;i<neighbourList_->getSize();++i)//for each site in the alignment
		{
		  if (neighbourList_->getOccuranceNum(i,0)!=-1)//if part i exists
		  {
		     tempP.sites.clear();
		     if (!inPartition[i])//if the site isn't already in the partition
		     {
		        tempP.sites.push_back(i);
		        inPartition[i]=true;
		
		        for (j=0;j<neighbourList_->getSize();++j)
		        {
		           //if site j occurs often with site i...
		           if ((i!=j)&&(neighbourList_->getOccuranceNum(i,j)>=(int)(occuranceLimit_*(iterations_-1))))
		           {
		              best=true;
		              for (k=0;k<neighbourList_->getSize();++k)//and site j occurs with i more than any other site...
		              {
		                 if(k!=i)
		                    best=best&&(neighbourList_->getOccuranceNum(i,j)>=neighbourList_->getOccuranceNum(k,j));
		                 if (best==false)
		                    break;
		              }
		              if (!inPartition[j])//and its not already in the partition...
		              {
		                 tempP.sites.push_back(j);//add it to the current part
		                 inPartition[j]=true;
		              }
		           }
		        }
		        if (tempP.sites.size()>0)//add the new part to the partitition
		           parts_.push_back(tempP);
		     }
		  }
		}
		partNum_=parts_.size();
		computeMSTBound_();
		return true;
	} else
		return false;

}
