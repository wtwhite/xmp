#include <iostream>
#include <iomanip>
#include <fstream>
#include <numeric>

#include "phylipTree.h"
#include "treeSiteList.h"
#include "outputLog.h"

using namespace std;

//file format information    
char CTreeSiteList::siteBeginning_ = ' ';
char CTreeSiteList::siteEnd_ = ' ';
char CTreeSiteList::siteSeparator_ = '\n';
char CTreeSiteList::valueSeparator_ = ':';

/**
   determines if a<b by comparing value members will result in lists sorted indescending order
   \version 1.0
   \param a pointer to a
   \param b pointer to b
   \return true if a<b
*/
bool operator<(const siteCost & a, const siteCost & b)
{
	return a.value > b.value;
}


/**
   create a list of site values from a tree
   \version 1.0
	\param fileName name of the tree file to open
	\param pa pointer to a phylip alignment
*/
CTreeSiteList::CTreeSiteList(string fileName, CPhylipAlignment * pa)
{
	int i;
	siteCost temp;
	vector < int >*tempSiteCosts;
	CPhylipTree *tree;

	tree = new CPhylipTree(fileName, pa);
	tempSiteCosts = tree->doRinsma(pa);
	delete tree;
	total_ = accumulate(tempSiteCosts->begin(), tempSiteCosts->end(), 0);

	for (i = 0; i < pa->getSeqLen(); ++i) {
		temp.pos = i;
		temp.index = pa->getIndex(i);
		temp.value = (*tempSiteCosts)[i];
		siteCosts_.push_back(temp);
	}
	sort(siteCosts_.begin(), siteCosts_.end());
	delete tempSiteCosts;
}


/**
   returns the value of a site at index in an alignment
   \version 1.0
	\param index index of the site in the list
	\return the value of the site 
*/
int CTreeSiteList::getSite(int index)
{
	int i;
	for (i = 0; i < siteCosts_.size(); ++i)
		if(siteCosts_[i].index == index)
			return siteCosts_[i].value;
}

/**
   returns the value of a site in position in the site list
   \version 1.0
	\param position index of the site in the list
	\return the value of the site 
*/
int CTreeSiteList::getSiteAtPosition(int position)
{
	int i;
	for (i = 0; i < siteCosts_.size(); ++i)
		if(siteCosts_[i].pos == position)
			return siteCosts_[i].value;
}


/**
   return the value of the bound from a tree
   \version 1.0
  	\return the total value of the bound from the tree
*/
int CTreeSiteList::getTotal()
{
	return total_;
}


/**
   writes a sorted list of site costs (gathered from tree data) to a file
   \version 1.0
   \param fileName file to output to
   \param alignmentFileName name of the alignment whose site costs are to be output
*/
void CTreeSiteList::writeSiteCosts(string fileName, string alignmentFileName)
{
	int i, j;
	ofstream output;

	output.open(fileName.c_str(), ios::out);
	if(!output)
		log() << "Error: cannot open file (" << fileName << ") for output.\n";
	else {
		output << " **********\n " << fileName.c_str() << "\n";
		output << " site costs for " << alignmentFileName << "\n";
		output << siteBeginning_ << "site" << ' ' << valueSeparator_ << " value" << siteEnd_ << siteSeparator_;
		if(siteSeparator_ != '\n')
			output << "\n";
		output <<
			" NOTE: if sites have a cost of 0 or were deliberatly excluded, they will not appear in this list\n";
		output << " NOTE: the site indices are the same as those in the actual alignment file\n";
		output << " **********\n\n";
		for (i = 0; i < siteCosts_.size(); ++i)
			output << siteBeginning_ << setw(3) << siteCosts_[i].
				index << setw(0) << ' ' << valueSeparator_ << ' ' << siteCosts_[i].
				value << siteEnd_ << siteSeparator_;
		output.close();
	}
}
