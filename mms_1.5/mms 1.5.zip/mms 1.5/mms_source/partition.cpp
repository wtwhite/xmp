#include <iostream>
#include <fstream>

#include "partition.h"
#include "distanceMatrix.h"
#include "outputLog.h"


using namespace std;

//file format information    
const char CPartition::pBeginning_='(';
const char CPartition::pEnd_=')';
const char CPartition::pSeparator_='\n';
const char CPartition::vSeparator_=',';
const char *CPartition::comment_="//";
   
/*some notes about partition file format

the partition file format can be changed by adjusting the values
pBeginning_, pEnd_, pSeparator_, vSeparator_, and comment_

pBeginning_ - this character denotes the beginning of a part
pEnd_ - this character denotes the end of a part
pSeparator_ - this character denotes a separation between two parts
vSeparator_ - this character separates values within a part
comment_ - this string is used to denote a comment

the generic format is as follows (for this description words inside [] characters
would appear as the appropriate value in a real file)

[comment]sometext
[exclusionList]
[partNum]
[partSize][pBeginning_]siteNum0[vSeparator_]siteNum1[pEnd_][pSeparator_]
[partSize][pBeginning_]siteNum0[vSeparator_]siteNum1[pEnd_][pSeparator_]
etc.
*/


/**
   initialises a partition
	\version 1.0
	\param pa pointer to a phylip alignment
*/
void CPartition::init_(CPhylipAlignment *pa)
{
   pa_=pa;
   sitesNum_=pa->getSeqLen();
}


CPartition::CPartition(CPhylipAlignment *pa) 
{
	init_(pa);
	generateTrivial_();
}
      	
/**
   generate a trivial partition
   \version 1.0
*/
void CPartition::generateTrivial_()
{
	int i;
	Part p;
	
 	partNum_=sitesNum_;
	for (i=0;i<sitesNum_;++i)
	{
		p.sites.push_back(i);
		parts_.push_back(p);
		p.sites.clear();
	}
	computeMSTBound_();
}


/**
   creates a copy of an existing partition
   \version 1.0
	\param p pointer to an existing partition
*/
CPartition::CPartition(CPartition *p)
{
	int i,j;
	Part tempP;

	pa_=p->pa_;
	partNum_=p->partNum_;
	sitesNum_=p->sitesNum_;
	bound_=p->bound_;


	for (i=0;i<partNum_;++i)
	{
		for (j=0;j<p->parts_[i].sites.size();++j)
		   tempP.sites.push_back(p->parts_[i].sites[j]);

		tempP.bound=p->parts_[i].bound;
		parts_.push_back(tempP);
		tempP.sites.clear();
	}
}


/**
   copies another partition into the current partition
   \version 1.0
	\param p pointer to an existing partition
*/
void CPartition::copy(CPartition *p)
{
	int i,j;
	Part tempP;

	pa_=p->pa_;
	partNum_=p->partNum_;
	sitesNum_=p->sitesNum_;
	bound_=p->bound_;

	parts_.clear();

	for (i=0;i<partNum_;++i)
	{
		for (j=0;j<p->parts_[i].sites.size();++j)
		   tempP.sites.push_back(p->parts_[i].sites[j]);

		tempP.bound=p->parts_[i].bound;
		parts_.push_back(tempP);
		tempP.sites.clear();
	}
}


/**
	writes a partition in a format readable by this app to a file
	\version 1.0
	\param fileName fileName to output the partition to
	\param optimal an optimal partition if present
*/
void CPartition::writePartition(string fileName,CPartition *optimal)
{
	int i,j;
   ofstream output;
   
   output.open(fileName.c_str(),ios::out);
  	if (!output)
		log() << "Error: cannot open file ("<<fileName<<") for output.\n";
   else
   {
      #if defined(USE_COMMENTS)
         output << comment_ << "**********\n"<<comment_<<" "<< fileName.c_str()<<"\n";
         output << comment_ <<" max lower bound "<<bound_;
         if (optimal!=NULL)
            output << "\n"<<comment_<<" upper bound "<<optimal->getMSTBound()<<"\n"<<comment_<<" max lower bound is "<<((optimal->getMSTBound()==bound_)?"":"not ")<<"equal to the upper bound";
         output << comment_ << "\n NOTE: if sites are excluded then site indices listed will not be the same as in the alignment file\n";
         output << comment_ << "       instead they list the position in the alignment once the excluded sites have been removed\n";
         output <<comment_<<"**********\n\n";
      #endif
      output << ((CFullAlignment *)pa_)->excludeString().c_str();
      #if defined(USE_COMMENTS)
         output << comment_ << " excluded sites\n\n";
      #else
         output << "\n\n";
      #endif
      output << partNum_;
      #if defined(USE_COMMENTS)
         output << comment_ << " number of parts in partition\n\n";
      #else
         output << "\n\n";
      #endif
      for (i=0;i<partNum_;++i)
      {
         output << parts_[i].sites.size() << pBeginning_ << parts_[i].sites[0];
         for (j=1;j<parts_[i].sites.size();++j)
            output << vSeparator_ << parts_[i].sites[j];
         output << pEnd_;
         #if defined(USE_COMMENTS)
            output<<comment_<<" bound "<<parts_[i].bound;
         	if (optimal!=NULL)
            	output << " optimised bound "<<optimal->getPartBound(i)<<" - " <<((parts_[i].bound==optimal->getPartBound(i))?"optimized":"unoptimized");
         #endif
         output << pSeparator_;
      }
      output.close();
   }
}

/**
   computes the bound of a partition
   \version 1.0
	\return integer representing the total bound for the partition
*/
int CPartition::computeMSTBound_()
{
	int i;
	
	bound_=0;
	
	
	i=0;
	while (i<partNum_)
	{
		parts_[i].bound=computeBound_(parts_[i]);
		bound_+=parts_[i].bound;
		++i;
	}
	
	return bound_;
}


/**
   computes the bound of a partition
	\version 1.0
	\param p part to compute the bound for
	\return integer representing the total bound for the partition
*/
int CPartition::computeBound_(Part &p)
{
	int temp;
	CPhylipAlignment *sub;
	CDistanceMatrix *dm;
	
	sub= new CSubAlignment(&(p.sites),pa_);
	dm = new CDistanceMatrix((CSubAlignment *)sub);	
	//find the bound for the submatrix
	temp=dm->computeOneConnected();
		
	//prevent memory leaks
	delete (CSubAlignment *) sub;
	delete dm;
	
	return temp;
}


/**
   gets the bound of a partition from the existing bound values
	\version 1.0
	\return integer representing the total bound for the partition
*/
int CPartition::getMSTBound()
{	
	return bound_;
}


/**
   returns the number of parts in a partition
   \version 1.0
	\return the number of parts in the partition
*/
int CPartition::getPartNum()
{
	return partNum_;
}

/**
   returns the number of sites in a partition
   \version 1.0
	\return the number of sites in the partition
*/
int CPartition::getSitesNum()
{
	return sitesNum_;
}


CPhylipAlignment *CPartition::getPhylipAlignment()
{
	return pa_;
}


/**
   delete part i and shift all elements back to fill in the gap left over and decrement the size of the parts array by one.
	\version 1.0
	\param i the index number in the parts array of the part to be deleted
*/
void CPartition::deletePart_(int i)
{
   parts_.erase(parts_.begin()+i);
   --partNum_;

}


/**
   append part p to the end of the parts array
	\version 1.0
	\param p the new part to be added to the partition
*/
void CPartition::addPart_(Part p)
{
   parts_.push_back(p);
   ++partNum_;
}


/**
   replace part i with a new part p
	\version 1.0
	\param i the index of the part to be replaced
	\param p the replacement part
*/
void CPartition::replacePart_(int i,Part p)
{
	parts_[i]=p;
}


/**
   merges parts i and j and updates the bound
	\version 1.0
	\param j the ndex of one of the parts
	\param i the index of the other part
	\param doMove if true: the merge is performed, false: the bound of the merge is returned but the merge itself is not performed	
	\return the improvement in the bound if doMove is false
*/
int CPartition::move_mergeParts(int i,int j,bool doMove)
{
	int a,pScore = parts_[i].bound+parts_[j].bound;
	Part newPart;
	
	//merge the contents of part[i] and part[j] to make newpart
	for (a=0;a<parts_[i].sites.size();++a)
		newPart.sites.push_back(parts_[i].sites[a]);
	for (a=0;a<parts_[j].sites.size();++a)
		newPart.sites.push_back(parts_[j].sites[a]);
	
	newPart.bound=computeBound_(newPart);
	
	if (doMove)//do the merge and return 0
	{
		replacePart_(i,newPart);
	 	deletePart_(j);//delete part j
	 	bound_+=(newPart.bound-pScore);//update the bound
	}
	
	return newPart.bound-pScore;//return the improvement in the bound
		
}


/**
   moves elem from part i into part j and updates the bound
	\version 1.0
	\param elem the index of the site in part i to be moved
	\param i the index of the part which elem is to be removed
	\param j the index of the part which elem is to be added
	\param doMove if true the move is performed, false the bound of the move is returned but the move itself is not performed
	\return the improvement in the bound if doMove is false, returns -1 if the move is invalid i.e part i has only one site
*/
int CPartition::move_oneElement(int elem,int i,int j,bool doMove)
{
	if (parts_[i].sites.size()<=1)
		return -1;
	
	Part newJ,newI;
	//Part *temp = new Part;	
	int a,b,pScore=parts_[i].bound+parts_[j].bound,newBound;
	
	//append elem to part j and store in newJ
	for (a=0;a<parts_[j].sites.size();++a)
		newJ.sites.push_back(parts_[j].sites[a]);
	newJ.sites.push_back(parts_[i].sites[elem]);
	
	for (a=0;a<parts_[i].sites.size();++a)
	  if (a!=elem)
	     newI.sites.push_back(parts_[i].sites[a]);
	
	newJ.bound=computeBound_(newJ);
	newI.bound=computeBound_(newI);
	newBound=newI.bound+newJ.bound;	
		
	if (doMove)//do the switch
	{		
		replacePart_(i,newI);
		replacePart_(j,newJ);
		bound_+=(newBound-pScore);//update the bound
	}

	return (newBound-pScore);//update the bound
}


/**
   returns the size of a part in a partition
	\version 1.0
	\param i index of the part in the partition
	\return the value of the size of part i
*/
int CPartition::getPartSize(int i)
{
	return parts_[i].sites.size();
}


/**
   returns the bound of a part in a partition
	\version 1.0
	\param i index of the part in the partition
	\return the value of the bound of part i
*/
int CPartition::getPartBound(int i)
{
   return parts_[i].bound;
}


/**
   determines if two taxa sequences in a part are the same
	\version 1.0
	\param part index of the part in the partition
	\param i index of the first taxa
	\param j index of the second taxa	
	\return true if the sequence in part is the same for taxa i and j, otherwise returns false
*/
bool CPartition::taxaEqual_(int part,int i,int j)
{
	int k,result;
	
	result=true;
	for (k=0;(k<parts_[part].sites.size())&&result;++k)
		result = result && (pa_->get(i,parts_[part].sites[k])==pa_->get(j,parts_[part].sites[k]));

	return result;
}


/**
   returns the part index to which a site belongs
	\version 1.0
	\param site - a site number in a partition
	\return the part index to which site belongs -1 if the site isn't in the partition
*/
int CPartition::getSitePartIndex(int site)
{
   int i,j;
   
   for (i=0;i<parts_.size();++i)
      for (j=0;j<parts_[i].sites.size();++j)
         if (parts_[i].sites[j] ==site)
            return i;
   return -1;
}   


/**
	returns the site number of the specified part
	\version 1.0
	\param part part index
	\param site site index
	\return the site number at the location specified
*/
int CPartition::getPartSite(int part,int site)
{
   return parts_[part].sites[site];
}


/**
   trivialises the parts listed in p and recomputes the bound
	\version 1.0
	\param p list of the parts to trivialise
*/
void CPartition::trivialiseParts(vector<int> *p)
{
   int i,j,pSize;
   Part tempP;
   
   for (i=0;i<p->size();++i)
      for (j=0;j<parts_[(*p)[i]].sites.size();++j)
      {
         tempP.sites.clear();
         tempP.sites.push_back(parts_[(*p)[i]].sites[j]);
         addPart_(tempP);
      }
   
   for (i=0,j=0,pSize=p->size();i<pSize;++i)
   {
      deletePart_((*p)[i]-j);  
      ++j;
   }
   computeMSTBound_();   
}
