#include <iostream>

#include "argList.h"
#include "outputLog.h"

using namespace std;


CArgList *CArgList::instance_ = NULL;

/**
 This provides a single access point to the class from all other classes
 \version 1.0
 \return the single instance of the singleton class
*/
CArgList *CArgList::instance()
{
	if(instance_ == NULL)
		instance_ = new CArgList();
	return instance_;
}

/**
 register an integer argument with the class
 \param name the name of the argument
 \param description a description of the arguments function
 \param allowMultipleValues whether to allow the argument to have multiple values assigned to it
 \version 1.0
*/
void CArgList::registerInt(string name, string description, bool allowMultipleValues)
{
	if(!isRegistered(name)) {
		CBaseArg *arg = new CArg < int >(allowMultipleValues);
		arg->setDescription(description);
		registeredArgs_[name] = arg;
	}
	else {
		log() << "Error: argument \"" << name << "\" has already been registered";
		log().flushBuffer();
		exit(1);
	}
}

/**
 register a string argument with the class
 \param name the name of the argument
 \param description a description of the arguments function
 \param allowMultipleValues whether to allow the argument to have multiple values assigned to it
 \version 1.0
*/
void CArgList::registerString(string name, string description, bool allowMultipleValues)
{
	if(!isRegistered(name)) {
		CBaseArg *arg = new CArg < string >(allowMultipleValues);
		arg->setDescription(description);
		registeredArgs_[name] = arg;
	}
	else {
		log() << "Error: argument \"" << name << "\" has already been registered";
		log().flushBuffer();
		exit(1);
	}
}

/**
 register a float argument with the class
 \param name the name of the argument
 \param description a description of the arguments function
 \param allowMultipleValues whether to allow the argument to have multiple values assigned to it
 \version 1.0
*/
void CArgList::registerFloat(string name, string description, bool allowMultipleValues)
{
	if(!isRegistered(name)) {
		CBaseArg *arg = new CArg < float >(allowMultipleValues);
		arg->setDescription(description);
		registeredArgs_[name] = arg;
	}
	else {
		log() << "Error: argument \"" << name << "\" has already been registered";
		log().flushBuffer();
		exit(1);
	}
}

/**
 register a string argument with the class
 \param name the name of the argument
 \param description a description of the arguments function
 \param allowMultipleValues whether to allow the argument to have multiple values assigned to it
 \version 1.0
*/
void CArgList::registerChar(string name, string description, bool allowMultipleValues)
{
	if(!isRegistered(name)) {
		CBaseArg *arg = new CArg < char >(allowMultipleValues);
		arg->setDescription(description);
		registeredArgs_[name] = arg;
	}
	else {
		log() << "Error: argument \"" << name << "\" has already been registered";
		log().flushBuffer();
		exit(1);
	}
}

/**
 unregister an argument from the class
 \param name the name of the argument to unregister
 \version 1.0
 */
void CArgList::unregisterArg(string name)
{
	registeredArgs_.erase(name);
}

/**
 determines whether an argument is currently registered or not
 \param name the name of the argument to be queried
 \version 1.0
*/
bool CArgList::isRegistered(string name)
{
	return registeredArgs_.find(name) != registeredArgs_.end();
}

/**
 determines whether an argument is currently assigned a value or not
 \param name the name of the argument to be queried
 \version 1.0
*/
bool CArgList::isAssigned(string name)
{
	if(isRegistered(name))
		return registeredArgs_[name]->isAssigned();
	else
		return false;
}

/**
 get an integer value from the given argument, if the argument has no integer value the program terminates
 \param name the name of the argument to be queried
 \return the value assigned to the argument
 \version 1.0
*/
int CArgList::getInt(string name)
{
	CArg < int >*a = dynamic_cast < CArg < int >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue();
	else {
		log() << "Error: argument \"" << name << "\" is not an int";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an char value from the given argument, if the argument has no char value the program terminates
 \param name the name of the argument to be queried
 \return the value assigned to the argument
 \version 1.0
*/
char CArgList::getChar(string name)
{
	CArg < char >*a = dynamic_cast < CArg < char >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue();
	else {
		log() << "Error: argument \"" << name << "\" is not a char";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an float value from the given argument, if the argument has no float value the program terminates
 \param name the name of the argument to be queried
 \return the value assigned to the argument
 \version 1.0
*/
float CArgList::getFloat(string name)
{
	CArg < float >*a = dynamic_cast < CArg < float >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue();
	else {
		log() << "Error: argument \"" << name << "\" is not a float";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an string value from the given argument, if the argument has no string value the program terminates
 \param name the name of the argument to be queried
 \return the value assigned to the argument
 \version 1.0
*/
string CArgList::getString(string name)
{
	CArg < string > *a = dynamic_cast < CArg < string > *>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue();
	else {
		log() << "Error: argument \"" << name << "\" is not a string";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an integer value from the given argument, if the argument has no integer value the program terminates
 \param name the name of the argument to be queried
 \param i the index of the value to get
 \return the value assigned to the argument
 \version 1.0
*/
int CArgList::getInt(string name,int i)
{
	CArg < int >*a = dynamic_cast < CArg < int >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue(i);
	else {
		log() << "Error: argument \"" << name << "\" is not an int";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an char value from the given argument, if the argument has no char value the program terminates
 \param name the name of the argument to be queried
 \param i the index of the value to get
 \return the value assigned to the argument
 \version 1.0
*/
char CArgList::getChar(string name,int i)
{
	CArg < char >*a = dynamic_cast < CArg < char >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue(i);
	else {
		log() << "Error: argument \"" << name << "\" is not a char";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an float value from the given argument, if the argument has no float value the program terminates
 \param name the name of the argument to be queried
 \param i the index of the value to get
 \return the value assigned to the argument
 \version 1.0
*/
float CArgList::getFloat(string name,int i)
{
	CArg < float >*a = dynamic_cast < CArg < float >*>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue(i);
	else {
		log() << "Error: argument \"" << name << "\" is not a float";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get an string value from the given argument, if the argument has no string value the program terminates
 \param name the name of the argument to be queried
 \param i the index of the value to get
 \return the value assigned to the argument
 \version 1.0
*/
string CArgList::getString(string name,int i)
{
	CArg < string > *a = dynamic_cast < CArg < string > *>(registeredArgs_[name]);
	if(a != 0)
		return a->getValue(i);
	else {
		log() << "Error: argument \"" << name << "\" is not a string";
		log().flushBuffer();
		exit(1);
	}
}

/**
 get the amount of values assigned to a particular argument
 \param name the name of the argument
 \return the amount of values assigned to a particular argument
 \version 1.0
 */
int CArgList::getCount(string name)
{
	return registeredArgs_[name]->getValueCount();	
}

/**
 set an integer value to the given argument, if the argument has no integer value the program terminates
 \param name the name of the argument to be queried
 \param value the value to be assigned to the argument
 \version 1.0
*/
void CArgList::addInt(string name, int value)
{
	CArg < int >*a = dynamic_cast < CArg < int >*>(registeredArgs_[name]);
	if(a != 0)
		a->addValue(value);
	else {
		log() << "argument \"" << name << "\" is not an int";
		log().flushBuffer();
		exit(1);
	}
}

/**
 set an char value to the given argument, if the argument has no char value the program terminates
 \param name the name of the argument to be queried
 \param value the value to be assigned to the argument
 \version 1.0
*/
void CArgList::addChar(string name, char value)
{
	CArg < char >*a = dynamic_cast < CArg < char >*>(registeredArgs_[name]);
	if(a != 0)
		a->addValue(value);
	else {
		log() << "Error: argument \"" << name << "\" is not a char";
		log().flushBuffer();
		exit(1);
	}
}

/**
 set an float value to the given argument, if the argument has no float value the program terminates
 \param name the name of the argument to be queried
 \param value the value to be assigned to the argument
 \version 1.0
*/
void CArgList::addFloat(string name, float value)
{
	CArg < float >*a = dynamic_cast < CArg < float >*>(registeredArgs_[name]);
	if(a != 0)
		a->addValue(value);
	else {
		log() << "Error: argument \"" << name << "\" is not a float";
		log().flushBuffer();
		exit(1);
	}
}

/**
 set an string value to the given argument, if the argument has no string value the program terminates
 \param name the name of the argument to be queried
 \param value the value to be assigned to the argument
 \version 1.0
*/
void CArgList::addString(string name, string value)
{
	CArg < string > *a = dynamic_cast < CArg < string > *>(registeredArgs_[name]);
	if(a != 0)
		a->addValue(value);
	else {
		log() << "Error: argument \"" << name << "\" is not a string";
		log().flushBuffer();
		exit(1);
	}
}

/**
 return the type of the current argument
 \param name the name of the argument to be queried
 \version 1.0
*/
string CArgList::getType_(string name)
{
	CArg < string > *a = dynamic_cast < CArg < string > *>(registeredArgs_[name]);
	if(a != 0)
		return "string";
	CArg < int >*b = dynamic_cast < CArg < int >*>(registeredArgs_[name]);
	if(b != 0)
		return "int";
	CArg < float >*c = dynamic_cast < CArg < float >*>(registeredArgs_[name]);
	if(c != 0)
		return "float";
	CArg < char >*d = dynamic_cast < CArg < char >*>(registeredArgs_[name]);
	if(d != 0)
		return "char";
	return "null";
}


/**	
	reads the argument from an argument value pair
	\version 1.0
	\param str input string
	\param separator character separating name and value
	\return lowercase string of the value of the argument in the input string.
*/

string CArgList::readArgName_(const char *str, char separator)
{
	unsigned int i = 0;
	string var;

	while((i < strlen(str)) && (str[i] != separator)) {
		var += tolower(str[i]);
		++i;
	}

	return var;
}


/**
   reads the value from an argument value pair
	\version 1.1
	\param str input string
   \param separator character separating name and value
	\return string of the value of the argument in the input string.
*/
string CArgList::readArgValue_(const char *str, char separator)
{
	unsigned int i;
	char *sepIndex = strchr(str, separator);
	string val;

	if(sepIndex != NULL) {
		i = (sepIndex - str) + 1;
		while(i < strlen(str))
			val += str[i++];
	}
	return val;
}


/**
	displays all non value arguments and their descriptions
   \version 1.2
*/
void CArgList::displayArgs()
{
	map < string, CBaseArg * >::iterator i;
	string desc;

	log() << "\nRegistered Arguments\n====================\n\n";
	for (i = registeredArgs_.begin(); i != registeredArgs_.end(); ++i) {
		desc = (i->second)->getDescription();
		wordWrap_(desc, strlen("description: "), 80);
		log() << i->first << " - (" << getType_(i->first) << ")\ndescription: " << (i->second)->
			getDescription() << "\n\n";
	}
}


/**
	adds word wrapping (assuming line length of 80 characters) to a string
	\version 1.0
	\param str the string to add word wrapping to
	\param initialPos the column index that the first character in the string appears on the screen
   \param lineLength maximum length of any one line
*/
void CArgList::wordWrap_(string & str, int initialPos, int lineLength)
{
	unsigned int i;
	int lastNewLine, lastSpace;

	for (i = 0, lastNewLine = initialPos, lastSpace = -1; i < str.size(); ++i) {
		if(str[i] == '\n')
			lastNewLine = 0;
		else
			++lastNewLine;

		if(str[i] == ' ')
			lastSpace = i;

		if((lastNewLine >= lineLength) && (lastSpace >= 0)) {
			str[lastSpace] = '\n';
			lastNewLine = (i - lastSpace);
			lastSpace = -1;
		}
	}
}
	
/**
 reads the arguments in from the command line and adds arguments that are registered
 \param argc the number of arguments
 \param argv the contents of the arguments
 \version 1.2
*/
void CArgList::readArgs(int argc, char **argv)
{
	//if the user has entered '?' then display help
	if (argc==2 && strcmp(argv[1],"?")==0) {
		CArgList::instance()->displayArgs();
		exit(0);
	}
	
	int i, tempI;
	float tempF;
	string name, value, type;
	char tempC;

	//read in arguments from the command line
	for (i = 1; i < argc; ++i) {
		name = readArgName_(argv[i], '=');
		value = readArgValue_(argv[i], '=');

		if((value.size() != 0) && isRegistered(name)) {
			try {
				type = getType_(name);

				if(type == "int") {
					if(sscanf(value.c_str(), " %d", &tempI) == 0)
						throw 0;
					addInt(name, tempI);
				}
				else if(type == "float") {
					if(sscanf(value.c_str(), " %f", &tempF) == 0)
						throw 0;
					addFloat(name, tempF);
				}
				else if(type == "char") {
					if(sscanf(value.c_str(), " %c", &tempC) == 0)
						throw 0;
					addChar(name, tempC);
				}
				else if(type == "string") {
					addString(name, value);
				}
			}
			catch(int i) {
				log() << "Error: invalid value type for argument \"" << name << "\" (expected " << type
					<< ").\n";
				log().flushBuffer();
				exit(1);
			}
		}
		else if(!isRegistered(name)) {
			log() << "Error: argument \"" << name <<
				"\" not recognised run \"" << argv[0] << " ?\" to see recognised arguments.\n";
			log().flushBuffer();
			exit(1);
		}
		else if(value.size() == 0) {
			log() << "Error: no value assigned to argument \"" << name << "\".\n";
			log().flushBuffer();
			exit(1);
		}

	}
}
