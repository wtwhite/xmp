#if !defined(UTILS_H)
#define UTILS_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

using namespace std;

/**
 convert an int to a string
 \version 1.0
 \param i an integer
 \return a string 
*/ 
string intToStr(int i);

/**
 convert a float to a string
 \param f a float
 \param precision the precision to round the float to (dp)
 \return a string
*/
string floatToStr(float f, int precision);

/**
 convert an int to a string with some formatting information
 \version 1.0
 \param i an integer
 \param fillChar a padding character
 \param width the minimum length of the string
 \return a string 
*/
string intToStr(int i, char fillChar, int width);

#endif
