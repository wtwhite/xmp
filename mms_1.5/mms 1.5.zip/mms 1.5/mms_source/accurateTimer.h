#ifndef ACCURATETIMER_H_
#define ACCURATETIMER_H_

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

using namespace std;

/**
 provides an accurate timer with time interval measured in seconds
 \author glenn conner
 \version 1.0
*/
class CAccurateTimer {
      public:
	CAccurateTimer();
	~CAccurateTimer();
	void startTimer();
	double stopTimer();
	string formatTime();
      private:
#ifdef _WIN32//windows specific timing code
	  __int64 start_, end_, freq_;
#else //less accurate but platform independant equivilant
	unsigned int end_,start_;
#endif
	
};

#endif /*ACCURATETIMER_H_ */
