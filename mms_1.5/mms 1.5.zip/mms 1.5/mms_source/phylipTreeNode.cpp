/*------------------------------------------------------------------------------
 * changes from 1.2 - 1.3
 * split root node and other nodes into separate classes (see phylipTree.cpp)
 *
 * changes from 1.1 - 1.2
 * rinsma algorithm now allows internal nodes with fixed states
 *
 * changes from 1.0 - 1.1
 * now reads newick files with internal node names and branchlength data (ignored)
 *----------------------------------------------------------------------------*/
#include <stdlib.h>

#include <iostream>
#include <fstream>
#include <algorithm>
#include <numeric>

#include "phylipTree.h"
#include "outputLog.h"


using namespace std;


/**
   recursive method which reads tree data in from a file
   \version 1.2
	\param is input file stream
	\param pAlignment pointer to a phylip alignment
	\param namedNodes leaves a vector containing all leaves on the tree (useful for fast leaf state setting from the root node)
*/
void CPhylipTreeNode::readTree_(ifstream & is, CPhylipAlignment * pAlignment, vector < CPhylipTreeNode * >&namedNodes)
{
	char ch;
	isNamed_ = false;	//assume node is unnamed

	is >> ch;		// Skips initial whitespace
	if(is.eof()) {
		log() << "Error: start of node expected.";
		log().flushBuffer();
		exit(1);
	}

	if(ch == '(') {
		// Read this parenthesised expression.
		do {
			CPhylipTreeNode *child = new CPhylipTreeNode();
			child->readTree_(is, pAlignment, namedNodes);
			children_.push_back(child);

			is >> ch;	// Skips initial whitespace
		} while(ch == ',');

		if(ch != ')') {
			log() << "Error: closing parenthesis expected.";
			log().flushBuffer();
			exit(1);
		}

		is >> ch;

		if(isalpha(ch))	//if this node has a name (and possibly a branchlength...skipped past by readname_())
		{
			is.putback(ch);
			nodeName_ = readName_(is);	//give the node a name
			setAsNamed_(pAlignment, nodeName_);
			namedNodes.push_back(this);	//add the named node to the roots list of named nodes    
		}
		else if(ch == ':')	//if the node has a branch length then skip past to the next node 
		{
			while(!strchr("),;", ch)) {
				ch = is.get();
				if(is.eof())
					break;
			}
			if(!is.eof())
				is.putback(ch);
		}
		else		//no branch or name data, so put the character back
			is.putback(ch);
	}
	else			//node is named on the tree
	{
		is.putback(ch);
		nodeName_ = readName_(is);
		setAsNamed_(pAlignment, nodeName_);
		namedNodes.push_back(this);	//add the named node to the roots list of named nodes       
	}
}


/**
   checks if a node has a valid name
   \version 1.0
   \param pAlignment alignment to check node name from
   \param name the name of the node
*/
void CPhylipTreeNode::setAsNamed_(CPhylipAlignment * pAlignment, string name)
{
	if(name.size()) {
		int i;
		for (i = 0; i < pAlignment->getTaxNum(); ++i) {	//checks to see if the node name is in the alignment
			if(pAlignment->getLabel(i) == name) {
				nodeTaxaNum_ = i;
				isNamed_ = true;
				break;
			}
		}
	}
	else {
		log() << "Error: taxa in tree has no name.";
		log().flushBuffer();
		exit(1);
	}

	if(!isNamed_) {
		log() << "Error: taxa name \"" << name << "\" in tree is not present in alignment.";
		log().flushBuffer();
		exit(1);
	}
}



/**
   reads a node name from a tree file. Also skips past any branch length data after the name.
   \version 1.1
	\param is input file stream
	\return the name of the node it the current position in is. 
*/
string CPhylipTreeNode::readName_(istream & is)
{
	char c;
	bool isColon;
	string str;

	is >> c;		// Formatted input always skips initial whitespace
	if(is.eof())
		return string();	// Empty string

	if((c == '"') || (c == '\'')) {
		// Read until next unbackslashed double-quote character
		while(c = is.get(), !is.eof()) {
			if(c == '"')
				break;
			if(c == '\'')
				break;
			if(c == '\\') {

				c = is.get();
				if(is.eof()) {
					log() << "Error: File ends after escaping backslash.\n";
					log().flushBuffer();
					exit(1);
				}

				switch (c) {
				case 'r':
					c = '\r';
					break;
				case 'n':
					c = '\n';
					break;
				case 't':
					c = '\t';
					break;
				case 'f':
					c = '\f';
					break;
				case '"':
					break;	// Leave c unchanged
				case '\\':
					break;	// Leave c unchanged
				default:
					str += '\\';	// Assume the backslash was unintentional
				}
			}

			str += c;
		}
	}
	else {
		// Read until next comma, colon, closing parenthesis or semicolon.
		// Remember there is a character in c to start with.
		isColon = false;
		while(!strchr("),;", c)) {
			if(c == ':')	//the rest of the name is branchlength data...skip past this
				isColon = true;
			if(!isColon)	//dont add branch length data to the name
				str += c;
			c = is.get();
			if(is.eof())
				break;
		}

		if(!is.eof())
			is.putback(c);
	}

	return str;
}


/**
   frees memory assigned to a tree
   \version 1.0
*/
CPhylipTreeNode::~CPhylipTreeNode()
{
	int i;

	for (i = 0; i < children_.size(); ++i)
		delete children_[i];
}

/**
   creates a tree
   \version 1.0
*/
CPhylipTreeNode::CPhylipTreeNode()
{
	isNamed_ = false;
}

/**
   gets the state/s of a node
   \version 1.0
	\return the state/s of a node
*/
vector < char >*CPhylipTreeNode::getState()
{
	return &states_;
}


/**
   sets a nodes character state
   \version 1.0
	\param newStates a vector of new character states
*/
void CPhylipTreeNode::setState(vector < char >&newStates)
{
	int i;

	states_.clear();
	for (i = 0; i < newStates.size(); ++i)
		states_.push_back(newStates[i]);
}


/**
   finds the cost of the tree using rinsmas algorithm, now supports nodes with fixed states
   that can't be chosen by the rinsma algorithm
   \version 1.2
	\return the cost of the tree using rinsmas algorithm
*/
int CPhylipTreeNode::rinsmaOnSite_()
{
	int i, j, k;
	int *max, minCost, totalMinCost = -1, result = 0;
	int resultList[4];
	char resultChars[] = { 'A', 'C', 'T', 'G' };
	bool notInState;
	vector < vector < char > >childStates;
	vector < char >state;

	for (i = 0; i < children_.size(); ++i)	//get results from children
		result += children_[i]->rinsmaOnSite_();

	checkStateCombinations_(childStates, state, 0, false);	//get a list of all possible child state combinations 

	for (i = 0; i < childStates.size(); ++i)	//search through the combinations
	{
		resultList[0] = 0;	//zero the array
		resultList[1] = 0;
		resultList[2] = 0;
		resultList[3] = 0;

		for (j = 0; j < childStates[i].size(); ++j)	//specify how many times a,c,t &g appear in this combination
		{
			switch ((childStates[i])[j]) {
			case 'A':
				++resultList[0];
				break;
			case 'C':
				++resultList[1];
				break;
			case 'T':
				++resultList[2];
				break;
			case 'G':
				++resultList[3];
				break;
			}
		}

		if(!isNamed_)	//state assigned to the internal node                 
			max = max_element(&resultList[0], &resultList[4]);	//find the most often occuring element for this combination
		else		//the internal node has a fixed state, force selection of this state regardless of the frequency of its occurance in child nodes
		{
			for (j = 0; j < 4; ++j)
				if(states_[0] == resultChars[j]) {
					max = &resultList[j];
					break;
				}
		}

		minCost = accumulate(&resultList[0], &resultList[4], 0) - *max;	//find the minimum cost for this combination

		if(!isNamed_)	//no state assigned to the internal node   
		{
			//clear the state/s vector and add the new states
			state.clear();
			if(resultList[3] == *max)
				state.push_back(resultChars[3]);
			if(resultList[2] == *max)
				state.push_back(resultChars[2]);
			if(resultList[1] == *max)
				state.push_back(resultChars[1]);
			if(resultList[0] == *max)
				state.push_back(resultChars[0]);
		}

		if(minCost < totalMinCost)	//if the cost for this combination is the least set the node state to the combination
		{
			totalMinCost = minCost;
			if(!isNamed_)
				setState(state);
		}
		else if(!isNamed_ && (minCost == totalMinCost))	//if there is an equal state add any states currently not
		{		//present (only for nodes without a fixed state)
			for (j = 0; j < state.size(); ++j) {
				for (k = 0, notInState = true; k < states_.size(); ++k) {
					notInState = notInState && (state[j] != states_[k]);
					if(!notInState)
						break;
				}
				if(notInState)
					states_.push_back(state[j]);
			}
		}
		else if(i == 0)	// if this is the first combination tested, set the state to this 
		{
			totalMinCost = minCost;
			if(!isNamed_)
				setState(state);
		}
	}
	return result + totalMinCost;	//cost of this node plus the cost of all child nodes                    
}


/**
   finds all possible combinations of the child nodes states
   \version 1.0
	\param childStates a vector of vectors representing all the possible states that the combination of child nodes can create
	\param state temporary variable that needs to be passed between recursive calls
	\param cIndex index of the first child to process
	\param mBefore true if there is a multistate node before the current node (eliminates redundant identical states appearing in childStates)
*/
void CPhylipTreeNode::checkStateCombinations_(vector < vector < char > >&childStates, vector < char >&state, int cIndex,
					      bool mBefore)
{
	int i, j;

	if(cIndex < children_.size()) {
		for (i = cIndex; i < children_.size(); ++i) {
			if(state.size() <= i)
				state.push_back((*children_[i]->getState())[0]);
			if((children_[i]->getState())->size() > 1) {
				for (j = 0; j < (children_[i]->getState())->size(); ++j)	//iterate through each possible state
				{
					state[i] = (*children_[i]->getState())[j];
					checkStateCombinations_(childStates, state, i + 1, true);	//recurse through the list
				}
				break;
			}
			else if(mBefore) {
				state[i] = (*children_[i]->getState())[0];
				checkStateCombinations_(childStates, state, i + 1, false);	//recurse through the list
			}
		}
	}
	else
		childStates.push_back(state);

	if(childStates.size() == 0)	//if there are no combinations return a single list
		childStates.push_back(state);
}


/**
   get method for the node taxa number for a named node
   \return node taxa number
*/
int CPhylipTreeNode::getNodeTaxaNum_()
{
	return nodeTaxaNum_;
}


/**
   set method for the node taxa number for a named node
   \param nodeTaxaNum node taxa number
*/
void CPhylipTreeNode::setNodeTaxaNum_(int nodeTaxaNum)
{
	nodeTaxaNum_ = nodeTaxaNum;
}
