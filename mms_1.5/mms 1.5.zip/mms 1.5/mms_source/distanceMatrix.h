#if !defined(DISTANCEMATRIX_H)
#define DISTANCEMATRIX_H

#include "phylipAlignment.h"

using namespace std;

/**
   a matrix of differences between taxa
   \version 1.1
   \author Glenn Conner
*/
class CDistanceMatrix {
      public:
	CDistanceMatrix(CSubAlignment *);
	~CDistanceMatrix();
	int computeOneConnected();
      private:
	int **m_;
	int taxaNum_;
	void oneConn_(int, int *, int, int *, int *);
	int *computeUniqueTaxa_(int *uTNum);
};

#endif
