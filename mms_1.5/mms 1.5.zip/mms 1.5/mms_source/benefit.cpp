#include "benefit.h"

using namespace std;

/**
	creates a benefit vector from firstElem to size
	\version 1.0
	\param firstElem the first element of the benefit vector
	\param size size of the partition
*/
CBenefit::CBenefit(int firstElem, int size)
{
	bData_ = new int[size - (firstElem + 1)];
	firstElem_ = firstElem;
}


/**
	frees memory allocated to a benefit vector
	\version 1.0
*/
CBenefit::~CBenefit()
{
	delete[]bData_;
}


/**
   sets the value of a subindice
	\version 1.0
	\param index the subindice toset
	\param nc2 the size of a hit vector
	\param a pointer to one hit vector
	\param b pointer to a second hit vector
*/
void CBenefit::setElem(int index, int nc2, int *a, int *b)
{
	int orSum, sumA, sumB, i;

	for (i = 0, orSum = 0, sumA = 0, sumB = 0; i < nc2; ++i) {
		orSum += (a[i] || b[i]);
		sumA += a[i];
		sumB += b[i];
	}

	if(sumA >= sumB)
		bData_[index - (firstElem_ + 1)] = orSum - sumA;
	else
		bData_[index - (firstElem_ + 1)] = orSum - sumB;
}


/**
   returns the pairSplit cost of a merge between two parts
	\version 1.0
	\param nc2 the size of a hit vector
	\param a pointer to one hit vector
	\param b pointer to a second hit vector
	\return the value of the cost of the prospective move 
*/
int CBenefit::getElemCost(int nc2, int *a, int *b)
{
	int i, sum;
	for (i = 0, sum = 0; i < nc2; ++i) {
		sum += (a[i] && b[i]);
	}
	return sum;
}


/**
   removes subindice index
	\version 1.0
	\param index subindicie to remove
	\param newSize size of the partition
*/
void CBenefit::removeBenefit(int index, int newSize)
{
	int i;

	for (i = index; i < newSize; ++i)
		bData_[i - (firstElem_ + 1)] = getElem(i + 1);
}


/**
   returns the value of a subindice
	getElem(int index)
	\version 1.0
	\param index subindicie
	\return the value of a subindicie
*/
int CBenefit::getElem(int index)
{
	return bData_[index - (firstElem_ + 1)];
}


/**
   decrements the value of firstElement_
   \version 1.0
*/
void CBenefit::decFirstElem()
{
	--firstElem_;
}


/**
   finds the greatest subindice element
   \version 1.0	
	\param size the size of the partition
	\return the index of the greatest subindice
*/
int CBenefit::getGreatestElem(int size)
{
	int i, max;
	for (i = firstElem_ + 1, max = -1; i < size; ++i)
		if(getElem(i) > max)
			max = i;

	return max;
}
