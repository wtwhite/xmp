#if !defined(PARTITIONFACTORY_H)
#define PARTITIONFACTORY_H

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#include "partition.h"
#include "filePartition.h"
#include "likelyGroupPartition.h"
#include "pairSplitPartition.h"
#include "treeSiteList.h"
#include "treePartition.h"
#include "phylipAlignment.h"
#include "treeSiteList.h"

using namespace std;

/**
 This factory class abstracts away the job of creating the various partition subclasses
 \author Glenn Conner
 \version 1.0
*/
class CPartitionFactory {
      public:
	static CPartition *copyPartition(CPartition *);
	static CPartition *loadPartition(CPhylipAlignment *, string name);
	static CPartition *trivialPartition(CPhylipAlignment *);
	static CPartition *pairSplitPartition(CPhylipAlignment *);
	static CPartition *likelyGroupPartition(CPhylipAlignment *, int learningPasses, float occuranceLimit);
	static CPartition *treePartition(CPartition *, CTreeSiteList *);
};

#endif
