#if !defined(TREEPARTITION_H)
#define TREEPARTITION_H

#include "partition.h"
#include "treeSiteList.h"

using namespace std;

class CTreePartition:public CPartition {
	public:
		CTreePartition(CPartition *p,CTreeSiteList *sites);
		~CTreePartition() {};
		
	  	bool update(CPartition *) {return false;};
};

#endif
