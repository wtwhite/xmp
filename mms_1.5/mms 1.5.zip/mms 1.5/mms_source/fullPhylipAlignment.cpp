#include <stdlib.h>
#include <ctype.h>

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>

#include "phylipAlignment.h"
#include "outputLog.h"

using namespace std;

//file format information    
char CFullAlignment::rangeSeparator_ = '-';
char CFullAlignment::siteSeparator_ = ',';
char CFullAlignment::end_ = ';';
/* exclusion string format
   [site]([siteseparator_] or [rangeseparator_])[site]([siteseparator_] or [rangeseparator_])[site][end_]
   NOTE: the end character is optinoal when parsing the string but is required when writing, as the load partition method expects it
*/

/**
   create an alignment given a phylip alignment file
   \version 1.0
	\param fileName the name of the file containing a phylip alignment
*/
CFullAlignment::CFullAlignment(string fileName)
{
	ReadPhylipAlignment_(fileName);
}


/**
   exclude sites in the exclusion string from the alignment
   \version 1.0
   \param excludedSites a string of comma or '-' separated sites
*/
void CFullAlignment::excludeSites(string excludedSites)
{
	int i;
	vector < int >*exclude = parseExcluded_(excludedSites);

	for (i = exclude->size() - 1; i > 0; --i)	//remove sites chosen for exclusion
		excludeSite_((*exclude)[i]);
	excludeSite_((*exclude)[0]);

	delete exclude;
}


/**
   frees memory allocated to an alignment
	\version 1.0
	\author Tim White - modified by Glenn Conner
*/
CFullAlignment::~CFullAlignment()
{
	unsigned i;
	delete data_;
	delete siteIndices_;

	for (i = 0; i < numTaxa_; ++i) {
		delete[]labels_[i];
	}
	delete[]labels_;

}


/**
   gets the character in an alignment
   \version 1.0
	\param taxon the index of the taxon
	\param column the index of the site for the given taxa
	\return character that occurs in the alignment at the requested position
*/
char CFullAlignment::get(int taxon, int column)
{
	return (*data_)[taxon][column];
}


/**
   gets the index of the site in an alignment
   \version 1.0
	\param column the index of the site for the given taxa
	\return character that occurs in the alignment at the requested position
*/
int CFullAlignment::getIndex(int column)
{
	return (*siteIndices_)[column];
}


/**
   get the sequence length of an alignment
   \version 1.0
	\return sequence length of an alignment
*/
int CFullAlignment::getSeqLen()
{
	return seqLen_;
}


/**
   reads in the data from a phylip alignment Now reads interleaved format files, and gives much better error reporting.
   \version 1.0
	\author Tim White - modified by Glenn Conner
	\param fileName file containing a phylip alignment
*/
void CFullAlignment::ReadPhylipAlignment_(string & fileName)
{
	char buf[80];		// Only needs to be big enough to hold the first line
	int i, j, charsRead = 0, line = 2,pos, lastPos;
	char c;
	TaxaSeq taxa;
	ifstream inputFile;

	inputFile.open(fileName.c_str(), ios::in);

	if(!inputFile) {
		log() << "Error: cannot open file (" << fileName << ").\n";
		log().flushBuffer();
		exit(1);
	}

	// Read first line
	inputFile.getline(buf, sizeof(buf));
	if(inputFile.eof()) {
		log() << "Error: no first line in alignment.\n";
		log().flushBuffer();
		exit(1);
	}

	sscanf(buf, "%d %d", &numTaxa_, &seqLen_);

	//set up the site index list
	siteIndices_ = new vector < int >;
	for (i = 0; i < seqLen_; ++i)
		siteIndices_->push_back(i);

	data_ = new vector < TaxaSeq >;
	labels_ = new char *[numTaxa_];

	while(charsRead < seqLen_) {
		if(inputFile.eof()) {
			log() << "Error: alignment contains " << charsRead << " sites (" << seqLen_ <<
				" sites specified in top line).\n";
			log().flushBuffer();
			exit(1);
		}

		pos = -1;
		for (i = 0; i < numTaxa_; ++i, ++line) {
			// Read label and terminate string at first space
			inputFile.get(buf, 11);	// 11 = 10 + '\n'
			if(inputFile.eof()) {
				log() << "Error: alignment only contains complete data for " << i << " taxa (" <<
					numTaxa_ << " taxa specified in top line).\n";
				log().flushBuffer();
				exit(1);
			}

			// Ignore blank lines
			if(*buf == '\0') {
				--i;
				continue;
			}

			// This way allows spaces *within* the taxon label
			if(!charsRead) {
				for (j = 9; buf[j] == ' '; --j) {
					buf[j] = 0;
				}

				// GCC - strips leading whitespace from a taxon label
				for (j = 0; j < strlen(buf); ++j)
					if(buf[j] != ' ')
						break;

				labels_[i] = new char[strlen(buf) + 1 - j];

				strcpy(labels_[i], &buf[j]);
			}

			// Read sequence data
			lastPos = pos;
			pos = 0;
			c = 0;
			taxa.clear();
			while(c != '\n') {
				inputFile.get(c);

				if(inputFile.eof()) {
					break;
				}

				switch ((char) toupper(c)) {
				case 'A':
				case 'C':
				case 'G':
				case 'T':
				case 'U':
				case 'R':
				case 'Y':
				case 'S':
				case 'W':
				case 'K':
				case 'M':
				case 'B':
				case 'D':
				case 'H':
				case 'V':
				case '-':
				case 'N':
					if(charsRead + pos == seqLen_) {
						log() << "Error: too many characters in alignment on line " << line <<
							".\n";
						log().flushBuffer();
						exit(1);
					}
					else {
						++pos;
						taxa.push_back(toupper(c));
						break;
					}

				case ' ':
				case '\t':
				case '\n':	// Why can't we do a multilevel break?  Damn.
					continue;

				default:
					log() << "Error: invalid character '" << c << "' in alignment on line " << line
						<< ".\n";
					log().flushBuffer();
					exit(1);
				}
			}

			if(lastPos != -1 && lastPos != pos) {
				log() << "Error: line " << line << " in alignment contains " << (pos >
												lastPos ? pos -
												lastPos : lastPos -
												pos) << " " << (pos >
														lastPos
														? "more"
														:
														"fewer")
					<< " sites than the first line in this group.\n";
				log().flushBuffer();
				exit(1);
			}
			data_->push_back(taxa);
		}

		charsRead += pos;
	}
	inputFile.close();
}


/**
   parses a string of sites to be excluded and stores them as a vector
   \version 1.0
   \param excludedSites a string of sites to be excluded
   \return a vector storing all the sites to be excluded
*/
vector < int >*CFullAlignment::parseExcluded_(string excludedSites)
{
	int i, j, tempVal, range;
	char *endChar;
	string temp;
	vector < int >*exclude = new vector < int >;

	if(!isdigit(excludedSites[0])) {
		log() << "Error: integer expected as first character of exclusion string\n";
		log().flushBuffer();
		exit(1);
	}

	i = 0;
	range = -1;
	while(i < excludedSites.length()) {
		temp = "";
		while(isdigit(excludedSites[i]))	//grab a string of digits
			temp += excludedSites[i++];
		tempVal = strtol(temp.c_str(), &endChar, 0);	//convert the string to an int

		if(range >= 0)	//if previous number had a range, then add all values between the range
			for (j = range + 1; j < tempVal; ++j)
				if(find(exclude->begin(), exclude->end(), tempVal) == exclude->end())	//don't allow duplicate entries
					exclude->push_back(j);

		if(find(exclude->begin(), exclude->end(), tempVal) == exclude->end())
			exclude->push_back(tempVal);	//add the value found to the list

		if(i < excludedSites.length()) {
			if(excludedSites[i] == siteSeparator_)
				range = -1;
			else if(excludedSites[i] == rangeSeparator_)
				range = tempVal;
			else if(excludedSites[i] == end_)
				i = excludedSites.length();
			else {
				log() << "Error: unrecognised character in exclusion string\n";
				log().flushBuffer();
				exit(1);
			}
			++i;
		}
	}
	sort(exclude->begin(), exclude->end());
	return exclude;
}


/**
   removes sites which add nothing to the bound
   \version 1.0
*/
void CFullAlignment::removeIrrelevantSites()
{
	int i, j, temp;
	bool irrelevant;

	for (i = seqLen_ - 1; i >= 0; --i)	//search for an irrelevant site (where all taxa have the same data for that site)
	{
		irrelevant = true;
		temp = (*data_)[0][i];
		for (j = 1; j < numTaxa_; ++j) {
			irrelevant = irrelevant && (temp == (*data_)[j][i]);
			temp = (*data_)[j][i];
			if(!irrelevant)
				break;
		}
		if(irrelevant)	//remove the irrelevant site from all taxa
		{
			excludeSite_(i);
		}
	}
}


/**
   removes a site from an alignment
   \version 1.0
   \param index the site to be removed
*/
void CFullAlignment::excludeSite_(int index)
{
	int i;
	if(index < seqLen_) {
		excluded_.push_back((*siteIndices_)[index]);
		siteIndices_->erase(siteIndices_->begin() + index);
		for (i = 0; i < numTaxa_; ++i)
			((*data_)[i]).erase(((*data_)[i]).begin() + index);
		--seqLen_;
	}
	else {
		log() << "Error: cannot remove site " << index << " as the site is not present in the alignment\n";
		log().flushBuffer();
		exit(1);
	}
}


/**
   creates a comma separated string (closed with a semicolon) that shows all sites excluded from the current alignment
   \version 1.0
   \return all excluded sites
*/
string CFullAlignment::excludeString()
{
	int i;
	ostringstream s;
	if(excluded_.size() > 0) {
		s << excluded_[0];
		for (i = 1; i < excluded_.size(); ++i)
			s << siteSeparator_ << excluded_[i];
	}
	s << end_;
	return s.str();
}
