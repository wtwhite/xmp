#if !defined(FILEPARTITION_H)
#define FILEPARTITION_H

#if !defined(STDIO_H)
#define STDIO_H
#include <stdio.h>
#endif

#if !defined(STRING_H)
#define STRING_H
#include <string>
#endif

#include "partition.h"
#include "phylipAlignment.h"

using namespace std;

class CFilePartition:public CPartition {
	public:
	  	CFilePartition(CPhylipAlignment *pa,string name);//load partition from file
	  	~CFilePartition(){};
	  	bool update(CPartition *p) {return false;};
	private:
		
		//IO methods
		void readPartition_(string);
		bool findNextInstance_(FILE *inputFile,char c);
		void skipComments_(FILE *inputFile);
};

#endif
