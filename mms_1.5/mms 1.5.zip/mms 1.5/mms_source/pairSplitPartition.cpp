#include "phylipAlignment.h"
#include "partition.h"
#include "pairSplitPartition.h"
#include "benefit.h"

using namespace std;

/**
   converts a trivial partition into a partition based upon the idea of splitting the maximum number of taxa pairs
   \version 1.0
*/
CPairSplitPartition::CPairSplitPartition(CPhylipAlignment *pa)
{
	int **hit;
	CBenefit **benefit;
	int i,j,k,num,p;
	int nc2;
	int tempMax,maxB, max[2];
   FILE *output;
   
   init_(pa);
   generateTrivial_();

	for (i=1,nc2=0;i<pa_->getTaxNum();++i)//determine NumTaxa choose 2
		nc2+=(pa_->getTaxNum()-i);
	
	//create the hit array
	hit = new int *[partNum_];
	for (i=0;i<partNum_;++i)
		hit[i]=new int[nc2];

	//set the contents of the hit array
	for (i=0;i<partNum_;++i)
		for (j=0,num=0;j<pa_->getTaxNum()-1;++j)
			for (k=j+1;k<pa_->getTaxNum();++k)
				hit[i][num++]=(int) !taxaEqual_(i,j,k);
				
	//create the benefit array			
	benefit = new CBenefit*[partNum_];
	for (i=0;i<partNum_-1;++i)
	{
		benefit[i] = new CBenefit(i,partNum_);
		for (j=i+1;j<partNum_;++j)
			benefit[i]->setElem(j,nc2,hit[i],hit[j]);
	}
	benefit[partNum_-1]=NULL;

	while(1)
	{
		for (i=0,maxB=-1;benefit[i]!=NULL;++i)
		{
			tempMax=benefit[i]->getElem(benefit[i]->getGreatestElem(partNum_));
         if ((benefit[i]->getGreatestElem(partNum_)>=0)&&((tempMax>maxB)||((tempMax==maxB)&&(benefit[i]->getElemCost(nc2,hit[i],hit[benefit[i]->getGreatestElem(partNum_)])<benefit[i]->getElemCost(nc2,hit[max[0]],hit[max[1]])))))
			{
				maxB=tempMax;
				max[0]=i;
				max[1]=benefit[i]->getGreatestElem(partNum_);
			}
		}
		if (maxB<=0)
			break;

		move_mergeParts(max[0],max[1],true);//do the beneficial pairsplit merge
		
		//update hit vector
		for (i=0;i<nc2;++i)//set new values
			hit[max[0]][i]=hit[max[0]][i]&&hit[max[1]][i];	
		
		delete[] hit[max[1]];//delete removed part hit element
		
		for (i=max[1];i<=partNum_;++i)//shift elements back to fill the gap
			hit[i]=hit[i+1];
			
		//update the benefit vector
		for (i=0;i<max[1];++i)//remove all max[1] subindices
			benefit[i]->removeBenefit(max[1],partNum_);

      if (benefit[max[1]]!=NULL)//if the element to be deleted is not at the end of the list
      {
         delete benefit[max[1]];//remove max[1] indicie
         for (i=max[1];benefit[i]!=NULL;++i) //shift all elements back
         {
            benefit[i]=benefit[i+1];
            if (benefit[i]!=NULL)
               benefit[i]->decFirstElem();
         }
      }
      else
      {
         delete benefit[max[1]-1];
         benefit[max[1]-1]=NULL;
      }

		for (i=0;i<max[0];++i)//update all max[0] subindices
			benefit[i]->setElem(max[0],nc2,hit[i],hit[max[0]]);
			
		for (i=max[0]+1;benefit[i]!=NULL;++i)//update the max[0] indicie
			benefit[max[0]]->setElem(i,nc2,hit[max[0]],hit[i]);	
	}

	for (i=0;i<partNum_;++i)
		delete[] hit[i];
	delete[] hit;

	for (i=0;benefit[i]!=NULL;++i)
		delete benefit[i];
	delete[] benefit;		
}
