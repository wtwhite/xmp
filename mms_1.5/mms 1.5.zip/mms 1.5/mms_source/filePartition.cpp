#include <stdlib.h>
#include <iostream>
#include <fstream>

#include "phylipAlignment.h"
#include "partition.h"
#include "filePartition.h"
#include "outputLog.h"

using namespace std;


CFilePartition::CFilePartition(CPhylipAlignment *pa,string name)
{
	init_(pa);
	readPartition_(name);
	computeMSTBound_();
}


/**
   reads a partition from a file
	\version 1.0
	\param fileName file to be read from
*/
void CFilePartition::readPartition_(string fileName)
{
	int i,j,pSize,temp;
	FILE *inputFile;
	char c,sTemp[5]="  %d";
	string exclude;
	Part tempP;
	
	sTemp[1]=vSeparator_;

	if ((inputFile=fopen(fileName.c_str(),"r"))==NULL)
	{
		log() << "Error: cannot open file ("<<fileName<<").\n";
		log().flushBuffer();
		exit(1);
	}

	#if defined(USE_COMMENTS)
		skipComments_(inputFile);
	#endif

	exclude="";
	while(!feof(inputFile))//read exclusion string from the file
	{
      fscanf(inputFile," %c",&c);
      if (c !=';')
         exclude+=c;      
      else
         break;
   }
   if (feof(inputFile))//if the string was not formatted correctly
	{
		log()<<"Error: no terminating ';' on exclusion string in " << fileName << ".";
		log().flushBuffer();
		exit(1);
	}  
   if (exclude!="")
      ((CFullAlignment *)pa_)->excludeSites(exclude);//exclude listed sites from the list
   
	#if defined(USE_COMMENTS)
		skipComments_(inputFile);
	#endif   
               
	if (fscanf(inputFile," %d",&partNum_)<0)
	{
		log()<<"Error: partition size in file "<<fileName<<" not specified.";
		log().flushBuffer();
		exit(1);
	}
   
	i=0;
	while (i<partNum_)
	{
		#if defined(USE_COMMENTS)
			skipComments_(inputFile);
		#endif
		if (fscanf(inputFile," %d",&pSize)>0)
		{

			if (findNextInstance_(inputFile,CPartition::pBeginning_))
			{
				for (j=0;j<pSize;++j)//read in the elements of the part
				{
					if (j==0 && fscanf(inputFile," %d",&temp)>0)
						tempP.sites.push_back(temp);
					else if(fscanf(inputFile,sTemp,&temp)>0)
						tempP.sites.push_back(temp);
					else
					{
						   log() << "Error: part "<<(i+1)<<", element "<<(j+1)<<" in "<<fileName<<" not specified.\n";
						   log().flushBuffer();
						   exit(1);
					}
				}
			   
				parts_.push_back(tempP);//add the part to the partition
				tempP.sites.clear();
				if (findNextInstance_(inputFile,CPartition::pEnd_))
					findNextInstance_(inputFile,CPartition::pSeparator_);
				else
				{
					log() << "Error: '"<<CPartition::pEnd_<<"' expected in "<<fileName<<" but not found.\n";
					log().flushBuffer();
					exit(1);
				}
			}
			else
			{
				log() << "Error: '"<<CPartition::pBeginning_<<"' expected in "<<fileName<<" but not found.\n";
				log().flushBuffer();
				exit(1);
			}	
		}
		else
		{
			log() << "Error: part "<<(i+1)<<"size in "<<fileName<<" not specified.\n";
			log().flushBuffer();
			exit(1);
		}	
		++i;
	}
	fclose(inputFile);
}


/**
   skips past any lines that begin with doble slash characters (which denotes a comment)
	\version 1.0
	\param inputFile pointer to the file to read from
*/
void CFilePartition::skipComments_(FILE *inputFile)
{
   int i;
   bool isComment=true;
   char sTemp[80];
   fpos_t *startPos;
   startPos=new fpos_t;
   
   while (1)
   {
      fgetpos(inputFile,startPos);
      fscanf(inputFile," %s",sTemp);
      fsetpos(inputFile,startPos);
      
      for (i=0;i<strlen(CPartition::comment_);++i)
         isComment=isComment&&(sTemp[i]==CPartition::comment_[i]);
         
      if (isComment)
         findNextInstance_(inputFile,'\n');
      else
         break;
   }
   delete startPos;
}	


/** 
   reads through a file character by character until a character c is found
	\version 1.0
	\param inputFile pointer to the file to be read from
	\param c the character being looked for
	\return returns true if the character is found, otherwise returns false 
*/
bool CFilePartition::findNextInstance_(FILE *inputFile,char c)
{
	while (fgetc(inputFile)!=c)
 		if (feof(inputFile))
 			return false;
 	return true;
}	
