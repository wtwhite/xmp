#if !defined(MOVELIST_H)
#define MOVELIST_H

#if !defined(VECTOR_H)
#include <vector>
#define VECTOR_H
#endif

#include "partition.h"

using namespace std;

/** 
   stores the types of move available 
*/
typedef enum { Move_oneElement, Move_merge } MoveType;


/**
   stores a move
*/
typedef struct {
	MoveType move;
	int param[3];
	int boundImp;
} Move;

/**
 stores a list of taxa site moves
 \version 1.1
 \author Glenn Conner
*/
class CMoveList {
      public:
	CMoveList() {		/* do nothing */
	};
	~CMoveList() {		/* do nothing */
	};
	void append(Move);
	void emptyList();
	void copy(CMoveList *);
	int getSize();
	Move *getMove(int index);
	void generateGoodMoves(CPartition * part);
	void appendNewMoves(Move * move, CPartition * part);
      private:
	void removeInvalidMoves_(Move * move);
	void readjustMoves_(Move * move);
	vector < Move > m_;
};

#endif
